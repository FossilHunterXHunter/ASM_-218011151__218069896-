/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import dataAccessLayer.StudentDAO;
import dataAccessLayer.TermConditionDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import repo.Student;
import repo.TermCondition;

/**
 *
 * @author Student
 */
public class TermConditionServlet extends HttpServlet {

    private TermConditionDAO termConditionDAO;
    private StudentDAO studentDAO;

    public void init() {
        termConditionDAO = new TermConditionDAO();
        studentDAO = new StudentDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String studentID = (String) session.getAttribute("username");
        try {
            termConditionDAO.CalculateTermCondition(studentID, request);
        } catch (SQLException ex) {
            Logger.getLogger(TermConditionServlet.class.getName()).log(Level.SEVERE, null, ex);
        }

        Student student = studentDAO.selectStudent(studentID, request);
        TermCondition termCondition = termConditionDAO.selectTermCondition(student.getTermConditionID(), request);

        RequestDispatcher dispatcher = request.getRequestDispatcher("studentMenu.jsp");
        request.setAttribute("termCondition", termCondition);
        dispatcher.forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("pathAction");

        try {
            switch (action) {
                case "insert":
                    insertTermCondition(request, response);
                    break;
                case "search":
                    searchTermCondition(request, response);
                    break;
                case "update":
                    updateTermCondition(request, response);
                    break;
                case "list":
                    listTermCondition(request, response);
                    break;
                default:
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    private void searchTermCondition(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("idSearch"));
        TermCondition existingTermCondition = termConditionDAO.selectTermCondition(id, request);
        // RequestDispatcher dispatcher = request.getRequestDispatcher("admin/manageProgramme.jsp");
        request.setAttribute("termCondition", existingTermCondition);
        //  dispatcher.forward(request, response);

    }

    private void insertTermCondition(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String StatusDescription = request.getParameter("StatusDescription");
        String Colour = request.getParameter("Colour");
        int CreditPercentage = Integer.parseInt(request.getParameter("CreditPercentage"));
        TermCondition newTermCondition = new TermCondition(StatusDescription, Colour, CreditPercentage);
        termConditionDAO.insertTermCondition(newTermCondition, request);
        // response.sendRedirect("list");
    }

    private void updateTermCondition(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("ID"));
        String StatusDescription = request.getParameter("StatusDescription");
        String Colour = request.getParameter("Colour");
        int CreditPercentage = Integer.parseInt(request.getParameter("CreditPercentage"));
        TermCondition updateTermCondition = new TermCondition(id, StatusDescription, Colour, CreditPercentage);
        termConditionDAO.updateTermCondition(updateTermCondition, request);
//        response.sendRedirect("list");
    }

    private void listTermCondition(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<TermCondition> listTermCondition = termConditionDAO.selectAllTermCondition(request);
        request.setAttribute("listTermCondition", listTermCondition);
        // RequestDispatcher dispatcher = request.getRequestDispatcher("admin/manageProgramme.jsp");
        //  dispatcher.forward(request, response);
    }

}
