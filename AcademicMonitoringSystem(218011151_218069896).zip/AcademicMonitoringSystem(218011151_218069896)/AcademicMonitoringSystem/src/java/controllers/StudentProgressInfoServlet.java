/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import dataAccessLayer.LecturerModuleDAO;
import dataAccessLayer.StudentProgressInfoDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import repo.AssessmentType;
import repo.LecturerModule;
import repo.StudentProgressInfo;

/**
 *
 * @author Student
 */
public class StudentProgressInfoServlet extends HttpServlet {

    private StudentProgressInfoDAO studentProgressInfoDAO;
    private LecturerModuleDAO lecturerModuleDAO;
    List<LecturerModule> listModule = null;
    List<AssessmentType> listAssessmentType = null;
    List<StudentProgressInfo> listStudentProgressInfo = null;

    public void init() {
        studentProgressInfoDAO = new StudentProgressInfoDAO();
        lecturerModuleDAO = new LecturerModuleDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            searchLecturerModulesByUserID(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(UserModulesServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("pathAction");

        try {
            switch (action) {
                case "search":
                    searchStudentsByModuleID(request, response);
                    break;
                case "update":
                    updateStudentProgressInfo(request, response);
                    break;

                default:
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    private void updateStudentProgressInfo(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        int id = Integer.parseInt(request.getParameter("spiID"));
        String StudentID = request.getParameter("stuID");
        int StudentModuleID = Integer.parseInt(request.getParameter("smID"));
        int AssessmentTypeID = Integer.parseInt(request.getParameter("AssessmentDrop"));
        String AssessmentDescription = request.getParameter("ad");
        int Mark = Integer.parseInt(request.getParameter("mark"));
        String Date = request.getParameter("date");
        StudentProgressInfo updateStudentProgressInfo = new StudentProgressInfo(id, StudentID, StudentModuleID, AssessmentTypeID, AssessmentDescription, Mark, Date);
        studentProgressInfoDAO.updateStudentProgressInfo(updateStudentProgressInfo, request);
        request.setAttribute("listModule", listModule);
        request.setAttribute("listAssessmentType", listAssessmentType);
        request.setAttribute("listStudentProgressInfo", listStudentProgressInfo);
        request.setAttribute("messageLbl", "Student marks updated succesfully");
        RequestDispatcher dispatcher = request.getRequestDispatcher("manageMarks.jsp");
        dispatcher.forward(request, response);

    }

    private void searchLecturerModulesByUserID(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        HttpSession session = request.getSession();
        String lid = (String) session.getAttribute("username");
        listModule = lecturerModuleDAO.selectLecturerModuleByUserID(lid, request);
        listAssessmentType = studentProgressInfoDAO.selectAllAssessmentType(request);

        request.setAttribute("listModule", listModule);
        request.setAttribute("listAssessmentType", listAssessmentType);
        RequestDispatcher dispatcher = request.getRequestDispatcher("manageMarks.jsp");
        dispatcher.forward(request, response);
    }

    private void searchStudentsByModuleID(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        int mid = Integer.parseInt(request.getParameter("moduleDrop"));
        int semester = Integer.parseInt(request.getParameter("semesterS"));
        listStudentProgressInfo = studentProgressInfoDAO.selectAllStudentsByModule(mid, semester, request);
        request.setAttribute("listModule", listModule);
        request.setAttribute("listAssessmentType", listAssessmentType);
        request.setAttribute("listStudentProgressInfo", listStudentProgressInfo);
        RequestDispatcher dispatcher = request.getRequestDispatcher("manageMarks.jsp");
        dispatcher.forward(request, response);
    }

}
