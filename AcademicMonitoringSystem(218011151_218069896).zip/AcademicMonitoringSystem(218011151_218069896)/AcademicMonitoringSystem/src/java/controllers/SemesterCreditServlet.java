/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import dataAccessLayer.SemesterCreditDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import repo.SemesterCredit;

/**
 *
 * @author Student
 */
public class SemesterCreditServlet extends HttpServlet {

    private SemesterCreditDAO semesterCreditDAO;

    public void init() {
        semesterCreditDAO = new SemesterCreditDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("pathAction");

        try {
            switch (action) {
                case "insert":
                    insertSemesterCredit(request, response);
                    break;
                case "search":
                    searchSemesterCredit(request, response);
                    break;
                case "update":
                    updateSemesterCredit(request, response);
                    break;
                case "list":
                    listSemesterCredit(request, response);
                    break;
                default:
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    private void searchSemesterCredit(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("idSearch"));
        SemesterCredit existingSemesterCredit = semesterCreditDAO.selectSemesterCredit(id, request);
        // RequestDispatcher dispatcher = request.getRequestDispatcher("admin/manageProgramme.jsp");
        request.setAttribute("semesterCredit", existingSemesterCredit);
        //   dispatcher.forward(request, response);

    }

    private void insertSemesterCredit(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int ProgrammeID = Integer.parseInt(request.getParameter("ProgrammeID"));
        int Credit = Integer.parseInt(request.getParameter("Credit"));
        SemesterCredit newSemesterCredit = new SemesterCredit(ProgrammeID, Credit);
        semesterCreditDAO.insertSemesterCredit(newSemesterCredit, request);
        // response.sendRedirect("list");
    }

    private void updateSemesterCredit(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("ID"));
        int ProgrammeID = Integer.parseInt(request.getParameter("ProgrammeID"));
        int Credit = Integer.parseInt(request.getParameter("Credit"));
        SemesterCredit updateSemesterCredit = new SemesterCredit(id, ProgrammeID, Credit);
        semesterCreditDAO.updateSemesterCredit(updateSemesterCredit, request);
//        response.sendRedirect("list");
    }

    private void listSemesterCredit(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<SemesterCredit> listSemesterCredit = semesterCreditDAO.selectAllSemesterCredit(request);
        request.setAttribute("listSemesterCredit", listSemesterCredit);
        // RequestDispatcher dispatcher = request.getRequestDispatcher("admin/manageProgramme.jsp");
        //  dispatcher.forward(request, response);
    }

}
