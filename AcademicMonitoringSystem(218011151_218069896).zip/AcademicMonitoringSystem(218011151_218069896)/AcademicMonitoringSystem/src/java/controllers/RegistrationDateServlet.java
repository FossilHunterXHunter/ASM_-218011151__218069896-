/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import dataAccessLayer.RegistrationDateDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import repo.RegistrationDate;

/**
 *
 * @author Student
 */
public class RegistrationDateServlet extends HttpServlet {

    private RegistrationDateDAO registrationDateDAO;

    public void init() {
        registrationDateDAO = new RegistrationDateDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("pathAction");

        try {
            switch (action) {
                case "search":
                    searchRegistrationDate(request, response);
                    break;
                case "update":
                    updateRegistrationDate(request, response);
                    break;
                default:
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    private void searchRegistrationDate(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        RegistrationDate existingRegistrationDate = registrationDateDAO.selectRegistrationDate(request);
        RequestDispatcher dispatcher = request.getRequestDispatcher("manageRegistration.jsp");
        request.setAttribute("existingRegistrationDate", existingRegistrationDate);
        dispatcher.forward(request, response);

    }

    private void updateRegistrationDate(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        String fromDate = request.getParameter("fromDate");
        String toDate = request.getParameter("toDate");
        System.out.println(toDate);
        RegistrationDate updateRegistrationDate = new RegistrationDate(fromDate, toDate);
        registrationDateDAO.updateRegistrationDate(updateRegistrationDate, request);
        RequestDispatcher dispatcher = request.getRequestDispatcher("manageRegistration.jsp");
        request.setAttribute("messageLbl", "Registration dates updated");
        dispatcher.forward(request, response);

    }
}
