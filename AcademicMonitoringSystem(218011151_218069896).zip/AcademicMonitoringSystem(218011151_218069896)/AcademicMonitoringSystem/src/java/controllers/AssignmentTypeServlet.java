/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import dataAccessLayer.AssignmentTypeDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import repo.AssessmentType;

/**
 *
 * @author Student
 */
public class AssignmentTypeServlet extends HttpServlet {

    private AssignmentTypeDAO assignmentTypeDAO;

    public void init() {
        assignmentTypeDAO = new AssignmentTypeDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("pathAction");

        try {
            switch (action) {
                case "insert":
                    insertAssignmentType(request, response);
                    break;
                case "search":
                    searchAssignmentType(request, response);
                    break;
                case "update":
                    updateAssignmentType(request, response);
                    break;
                case "list":
                    listAssignmentType(request, response);
                    break;
                default:
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    private void searchAssignmentType(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("idSearch"));
        AssessmentType existingAssignmentType = assignmentTypeDAO.selectAssessmentType(id, request);
        //  RequestDispatcher dispatcher = request.getRequestDispatcher("admin/manageProgramme.jsp");
        request.setAttribute("existingAssignmentType", existingAssignmentType);
        // dispatcher.forward(request, response);

    }

    private void insertAssignmentType(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String markDescription = request.getParameter("markDescription");
        AssessmentType newAssignmentType = new AssessmentType(markDescription);
        assignmentTypeDAO.insertAssessmentType(newAssignmentType, request);
        // response.sendRedirect("list");
    }

    private void updateAssignmentType(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("ID"));
        String markDescription = request.getParameter("markDescription");
        AssessmentType updateAssignmentType = new AssessmentType(id, markDescription);
        assignmentTypeDAO.updateAssessmentType(updateAssignmentType, request);
//        response.sendRedirect("list");
    }

    private void listAssignmentType(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<AssessmentType> listAssignmentType = assignmentTypeDAO.selectAllAssessmentTypes(request);
        request.setAttribute("listAssignmentType", listAssignmentType);
        // RequestDispatcher dispatcher = request.getRequestDispatcher("admin/manageProgramme.jsp");
        //dispatcher.forward(request, response);
    }

}
