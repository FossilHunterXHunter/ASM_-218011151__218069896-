/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import dataAccessLayer.LecturerModuleDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import repo.LecturerModule;
import repo.Module;
import repo.User;

/**
 *
 * @author Student
 */
public class LecturerModuleServlet extends HttpServlet {

    private LecturerModuleDAO lecturerModuleDAO;

    public void init() {
        lecturerModuleDAO = new LecturerModuleDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("pathAction");

        try {
            switch (action) {
                case "insert":
                    insertLecturerModule(request, response);
                    break;
                case "search":
                    searchLecturersAndModules(request, response);
                    break;
                case "update":
                    updateLecturerModule(request, response);
                    break;
                case "list":
                    listLecturerModules(request, response);
                    break;

                default:
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    private void searchLecturerModule(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("idSearch"));
        LecturerModule existingsearchLecturerModule = lecturerModuleDAO.selectLecturerModule(id, request);
        // RequestDispatcher dispatcher = request.getRequestDispatcher("admin/manageModule.jsp");
        request.setAttribute("existingsearchLecturerModule", existingsearchLecturerModule);
        //  dispatcher.forward(request, response);

    }

    private void insertLecturerModule(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        String LecturerID = request.getParameter("lecturerDrop");
        int ModuleID = Integer.parseInt(request.getParameter("moduleDrop"));
        int Year = Integer.parseInt(request.getParameter("year"));
        int Semester = Integer.parseInt(request.getParameter("semester"));
        LecturerModule newlecturerModule = new LecturerModule(LecturerID, ModuleID, Year, Semester);
        lecturerModuleDAO.insertLecturerModule(newlecturerModule, request);
        RequestDispatcher dispatcher = request.getRequestDispatcher("assignLecturerToModule.jsp");
        request.setAttribute("messageLbl", "Lecturer assigned");
        dispatcher.forward(request, response);
    }

    private void updateLecturerModule(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("ID"));
        String LecturerID = request.getParameter("LecturerID");
        int ModuleID = Integer.parseInt(request.getParameter("ModuleID"));
        int Year = Integer.parseInt(request.getParameter("Year"));
        int Semester = Integer.parseInt(request.getParameter("Semester"));
        LecturerModule updatelecturerModule = new LecturerModule(id, LecturerID, ModuleID, Year, Semester);
        lecturerModuleDAO.updateLecturerModule(updatelecturerModule, request);
//        response.sendRedirect("list");
    }

    private void listLecturerModules(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<LecturerModule> listLecturerModule = lecturerModuleDAO.selectAllLecturerModule(request);
        request.setAttribute("listLecturerModule", listLecturerModule);
        // RequestDispatcher dispatcher = request.getRequestDispatcher("admin/manageModules.jsp");
        //  dispatcher.forward(request, response);
    }

    private void searchLecturersAndModules(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        String moduleName = request.getParameter("mName");
        String lecturerName = request.getParameter("lName");
        List<Module> listModule = lecturerModuleDAO.selectModuleByName(moduleName, request);
        List<User> listLecturer = lecturerModuleDAO.selectLecturerByName(lecturerName, request);
        request.setAttribute("listModule", listModule);
        request.setAttribute("listLecturer", listLecturer);
        RequestDispatcher dispatcher = request.getRequestDispatcher("assignLecturerToModule.jsp");
        dispatcher.forward(request, response);
    }

}
