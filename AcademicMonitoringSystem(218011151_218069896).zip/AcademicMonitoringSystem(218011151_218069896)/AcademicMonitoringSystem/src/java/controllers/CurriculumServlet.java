/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import dataAccessLayer.CurriculumDAO;
import dataAccessLayer.ModuleDAO;
import dataAccessLayer.ProgrammeDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import repo.Curriculum;
import repo.Module;
import repo.Programme;

/**
 *
 * @author Student
 */
public class CurriculumServlet extends HttpServlet {

    private CurriculumDAO curriculumDAO;
    private ModuleDAO moduleDAO;
    private ProgrammeDAO programmeDAO;
    List<Module> listModule = new ArrayList<>();
    List<Programme> listProgramme = new ArrayList<>();

    public void init() {
        curriculumDAO = new CurriculumDAO();
        moduleDAO = new ModuleDAO();
        programmeDAO = new ProgrammeDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        listModule = moduleDAO.selectAllModules(request);
        listProgramme = programmeDAO.selectAllProgrammes(request);
        request.setAttribute("listModule", listModule);
        request.setAttribute("listProgramme", listProgramme);
        RequestDispatcher dispatcher = request.getRequestDispatcher("manageCurriculum.jsp");
        dispatcher.forward(request, response);

    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("pathAction");

        try {
            switch (action) {
                case "insert":
                    insertCurriculum(request, response);
                    break;
                case "search":
                    searchCurriculum(request, response);
                    break;
                case "search module":
                    searchModuleByName(request, response);
                    break;
                case "update":
                    updateCurriculum(request, response);
                    break;
                //         case "list":
                //            listCurriculum(request, response);
                //             break;
                default:
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    private void searchModuleByName(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        //      String moduleName = request.getParameter("mName");
        //      List<Module> listModule = moduleDAO.selectModuleByCode(code, request);
        //      RequestDispatcher dispatcher = request.getRequestDispatcher("manageCurriculum.jsp");
        //      request.setAttribute("module", existingsearchModule);
        //      if (existingsearchModule == null) {
        //          request.setAttribute("messageLbl", "No modules found");
        //      }
        //     dispatcher.forward(request, response);

    }

    private void searchCurriculum(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        String programmeName = request.getParameter("pName");
        List<Curriculum> listCurriculum = curriculumDAO.selectAllCurriculumsByProgrammeName(programmeName, request);
        Programme programme = programmeDAO.selectProgramme(listCurriculum.get(0).getProgrammeID(), request);
        request.setAttribute("listCurriculum", listCurriculum);
        request.setAttribute("programme", programme);
        request.setAttribute("listModule", listModule);
        request.setAttribute("listProgramme", listProgramme);
        RequestDispatcher dispatcher = request.getRequestDispatcher("manageCurriculum.jsp");
        dispatcher.forward(request, response);

    }

    private void insertCurriculum(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        int ProgrammeID = Integer.parseInt(request.getParameter("programmeDrop"));
        int Semester = Integer.parseInt(request.getParameter("semester"));
        int ModuleID = Integer.parseInt(request.getParameter("moduleDrop"));
        int Year = Integer.parseInt(request.getParameter("year"));
        String ModuleType = request.getParameter("moduleType");
        String co_req = request.getParameter("corequisite");
        String pre_req = request.getParameter("prerequisite");

        Curriculum newCurriculum = new Curriculum(ProgrammeID, Year, Semester, ModuleID, ModuleType, pre_req, co_req);
        curriculumDAO.insertCurriculum(newCurriculum, request);
        request.setAttribute("listModule", listModule);
        request.setAttribute("listProgramme", listProgramme);
        RequestDispatcher dispatcher = request.getRequestDispatcher("manageCurriculum.jsp");
        request.setAttribute("messageLbl", "Curriculum added successfully");
        dispatcher.forward(request, response);
    }

    private void updateCurriculum(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        int id = Integer.parseInt(request.getParameter("cId"));
        int ProgrammeID = Integer.parseInt(request.getParameter("programmeDrop"));
        int Semester = Integer.parseInt(request.getParameter("semester"));
        int ModuleID = Integer.parseInt(request.getParameter("moduleDrop"));
        int Year = Integer.parseInt(request.getParameter("year"));
        String ModuleType = request.getParameter("moduleType");
        String co_req = request.getParameter("corequisite");
        String pre_req = request.getParameter("prerequisite");

        Curriculum updateCurriculumInfo = new Curriculum(id, ProgrammeID, Year, Semester, ModuleID, ModuleType, pre_req, co_req);
        curriculumDAO.updateCurriculum(updateCurriculumInfo, request);
        request.setAttribute("listModule", listModule);
        request.setAttribute("listProgramme", listProgramme);

        RequestDispatcher dispatcher = request.getRequestDispatcher("manageCurriculum.jsp");
        request.setAttribute("messageLbl", "Curriculum updated successfully");
        dispatcher.forward(request, response);
        response.sendRedirect("list");
    }
    /*
    private void listCurriculum(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<Curriculum> listCurriculum = curriculumDAO.selectAllCurriculums(request);
        request.setAttribute("listCurriculum", listCurriculum);
        //   RequestDispatcher dispatcher = request.getRequestDispatcher("admin/manageProgramme.jsp");
        //   dispatcher.forward(request, response);
    }*/

}
