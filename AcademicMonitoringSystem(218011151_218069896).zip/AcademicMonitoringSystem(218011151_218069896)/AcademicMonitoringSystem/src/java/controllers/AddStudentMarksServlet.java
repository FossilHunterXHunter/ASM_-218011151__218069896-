/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import dataAccessLayer.LecturerModuleDAO;
import dataAccessLayer.StudentProgressInfoDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
import repo.AssessmentType;
import repo.LecturerModule;
import repo.StudentProgressInfo;

/**
 *
 * @author Student
 */
@MultipartConfig(location = "/tmp", fileSizeThreshold = 1024 * 1024,
        maxFileSize = 1024 * 1024 * 5, maxRequestSize = 1024 * 1024 * 5 * 5)
public class AddStudentMarksServlet extends HttpServlet {

    private StudentProgressInfoDAO studentProgressInfoDAO;
    private LecturerModuleDAO lecturerModuleDAO;
    List<LecturerModule> listModule = null;
    List<AssessmentType> listAssessmentType = null;

    public void init() {
        studentProgressInfoDAO = new StudentProgressInfoDAO();
        lecturerModuleDAO = new LecturerModuleDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            searchLecturerModulesByUserID(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(UserModulesServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("pathAction");

        try {
            switch (action) {
                case "insert":
                    insertStudentProgressInfo(request, response);
                    break;

                default:
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    private void insertStudentProgressInfo(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        int moduleID = Integer.parseInt(request.getParameter("moduleDrop"));
        int AssessmentTypeID = Integer.parseInt(request.getParameter("AssessmentDrop"));

        int semester = Integer.parseInt(request.getParameter("semester"));
        String AssessmentDescription = request.getParameter("ad");

        Part filePart = request.getPart("fileSelect"); // Retrieves <input type="file" name="file">
        String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString(); // MSIE fix.

        studentProgressInfoDAO.insertStudentProgressInfoCSV(filePart, moduleID, AssessmentTypeID, semester, AssessmentDescription, request);

        request.setAttribute("listModule", listModule);
        request.setAttribute("listAssessmentType", listAssessmentType);
        request.setAttribute("messageLbl", "Student marks added succesfully");
        RequestDispatcher dispatcher = request.getRequestDispatcher("addMarks.jsp");
        dispatcher.forward(request, response);
    }

    private void searchLecturerModulesByUserID(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        HttpSession session = request.getSession();
        String lid = (String) session.getAttribute("username");
        listModule = lecturerModuleDAO.selectLecturerModuleByUserID(lid, request);
        listAssessmentType = studentProgressInfoDAO.selectAllAssessmentType(request);

        request.setAttribute("listModule", listModule);
        request.setAttribute("listAssessmentType", listAssessmentType);
        RequestDispatcher dispatcher = request.getRequestDispatcher("addMarks.jsp");
        dispatcher.forward(request, response);
    }

}
