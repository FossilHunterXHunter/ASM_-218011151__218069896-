/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import dataAccessLayer.LecturerModuleDAO;
import dataAccessLayer.StudentProgressInfoDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import repo.AssessmentType;
import repo.LecturerModule;
import repo.StudentProgressInfo;

/**
 *
 * @author Student
 */
public class StudentMarksServlet extends HttpServlet {

    private StudentProgressInfoDAO studentProgressInfoDAO;

    public void init() {
        studentProgressInfoDAO = new StudentProgressInfoDAO();

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            searchStudentMarks(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(UserModulesServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void searchStudentMarks(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        HttpSession session = request.getSession();
        String studentID = (String) session.getAttribute("username");

        List<List<StudentProgressInfo>> allList = studentProgressInfoDAO.selectStudentMarks(studentID, request);

        request.setAttribute("allList", allList);

        RequestDispatcher dispatcher = request.getRequestDispatcher("viewMarks.jsp");
        dispatcher.forward(request, response);

    }

}
