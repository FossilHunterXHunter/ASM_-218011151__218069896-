/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import dataAccessLayer.CurriculumDAO;
import dataAccessLayer.ModuleDAO;
import dataAccessLayer.ProgrammeDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import repo.Curriculum;
import repo.Module;
import repo.Programme;

/**
 *
 * @author Student
 */
public class AddCurriculumServlet extends HttpServlet {

    private CurriculumDAO curriculumDAO;
    private ModuleDAO moduleDAO;
    private ProgrammeDAO programmeDAO;
    List<Module> listModule = new ArrayList<>();
    List<Programme> listProgramme = new ArrayList<>();

    public void init() {
        curriculumDAO = new CurriculumDAO();
        moduleDAO = new ModuleDAO();
        programmeDAO = new ProgrammeDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        listModule = moduleDAO.selectAllModules(request);
        listProgramme = programmeDAO.selectAllProgrammes(request);
        request.setAttribute("listModule", listModule);
        request.setAttribute("listProgramme", listProgramme);
        RequestDispatcher dispatcher = request.getRequestDispatcher("addCurriculum.jsp");
        dispatcher.forward(request, response);

    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("pathAction");

        try {
            switch (action) {
                case "insert":
                    insertCurriculum(request, response);
                    break;
                default:
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    private void insertCurriculum(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        int ProgrammeID = Integer.parseInt(request.getParameter("programmeDrop"));
        int Semester = Integer.parseInt(request.getParameter("semester"));
        int ModuleID = Integer.parseInt(request.getParameter("moduleDrop"));
        int Year = Integer.parseInt(request.getParameter("year"));
        String ModuleType = request.getParameter("moduleType");
        String co_req = request.getParameter("corequisite");
        String pre_req = request.getParameter("prerequisite");

        Curriculum newCurriculum = new Curriculum(ProgrammeID, Year, Semester, ModuleID, ModuleType, pre_req, co_req);
        curriculumDAO.insertCurriculum(newCurriculum, request);
        request.setAttribute("listModule", listModule);
        request.setAttribute("listProgramme", listProgramme);
        RequestDispatcher dispatcher = request.getRequestDispatcher("addCurriculum.jsp");
        request.setAttribute("messageLbl", "Curriculum added successfully");
        dispatcher.forward(request, response);
    }

}
