/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import dataAccessLayer.MinCollegeReqDAO;
import java.util.List;
import dataAccessLayer.ProgrammeDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import repo.MinCollegeRequirements;
import repo.Programme;

/**
 *
 * @author Student
 */
public class ProgrammeServlet extends HttpServlet {

    private ProgrammeDAO programmeDAO;
    private MinCollegeReqDAO minCollegeReqDAO;
    List<MinCollegeRequirements> mcrs = new ArrayList<>();

    public void init() {
        programmeDAO = new ProgrammeDAO();
        minCollegeReqDAO = new MinCollegeReqDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        mcrs = minCollegeReqDAO.selectAllMinCollegeRequirements(request);
        request.setAttribute("mcrs", mcrs);
        RequestDispatcher dispatcher = request.getRequestDispatcher("manageProgramme.jsp");
        dispatcher.forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("pathAction");

        try {
            switch (action) {
                case "insert":
                    insertProgramme(request, response);
                    break;
                case "search":
                    searchProgramme(request, response);
                    break;
                case "update":
                    updateProgramme(request, response);
                    break;
                case "list":
                    listProgrammes(request, response);
                    break;
                default:
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    private void searchProgramme(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        String programmeName = request.getParameter("programmeNameS");
        Programme existingProgramme = programmeDAO.selectProgrammeByName(programmeName, request);
        RequestDispatcher dispatcher = request.getRequestDispatcher("manageProgramme.jsp");
        request.setAttribute("programme", existingProgramme);
        if (existingProgramme == null) {
            request.setAttribute("messageLbl", "Programme not found");
        }
        request.setAttribute("mcrs", mcrs);

        dispatcher.forward(request, response);

    }

    private void insertProgramme(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        String programmeName = request.getParameter("programmeName");
        int totalCredits = Integer.parseInt(request.getParameter("totalCredits"));
        int numberOfYears = Integer.parseInt(request.getParameter("noYears"));
        int collegeID = Integer.parseInt(request.getParameter("college"));
        Programme newProgramme = new Programme(programmeName, totalCredits, numberOfYears, collegeID);

        programmeDAO.insertProgramme(newProgramme, request);
        RequestDispatcher dispatcher = request.getRequestDispatcher("manageProgramme.jsp");
        request.setAttribute("messageLbl", "Programme added sucessfully");
        request.setAttribute("mcrs", mcrs);
        dispatcher.forward(request, response);

    }

    private void updateProgramme(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        int id = Integer.parseInt(request.getParameter("idU"));
        String programmeName = request.getParameter("programmeNameU");
        int totalCredits = Integer.parseInt(request.getParameter("totalCreditsU"));
        int numberOfYears = Integer.parseInt(request.getParameter("noYearsU"));
        int collegeID = Integer.parseInt(request.getParameter("collegeU"));
        Programme updateProgrammeInfo = new Programme(id, programmeName, totalCredits, numberOfYears, collegeID);
        programmeDAO.updateProgramme(updateProgrammeInfo, request);
        RequestDispatcher dispatcher = request.getRequestDispatcher("manageProgramme.jsp");
        request.setAttribute("messageLbl", "Programme updated sucessfully");
        request.setAttribute("mcrs", mcrs);
        dispatcher.forward(request, response);
    }

    private void listProgrammes(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<Programme> listProgramme = programmeDAO.selectAllProgrammes(request);
        request.setAttribute("listProgramme", listProgramme);
        RequestDispatcher dispatcher = request.getRequestDispatcher("manageProgramme.jsp");
        request.setAttribute("mcrs", mcrs);
        dispatcher.forward(request, response);
    }

}
