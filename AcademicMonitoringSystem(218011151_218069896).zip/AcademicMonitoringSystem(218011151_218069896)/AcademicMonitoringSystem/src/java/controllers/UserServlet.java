/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import dataAccessLayer.ProgrammeDAO;
import dataAccessLayer.StudentDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dataAccessLayer.UserDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import repo.Programme;
import repo.Student;
import repo.User;

/**
 *
 * @author Student
 */
public class UserServlet extends HttpServlet {

    // private static final long serialVersionUID = 1 L;
    private UserDAO userDAO;
    private ProgrammeDAO programmeDAO;
    List<Programme> listProgramme = new ArrayList<>();
    StudentDAO studentDAO;
    Student student = null;

    public void init() {
        userDAO = new UserDAO();
        programmeDAO = new ProgrammeDAO();
        studentDAO = new StudentDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("pathAction");

        try {
            switch (action) {
                case "insert":
                    insertUser(request, response);
                    break;
                case "search":
                    searchUser(request, response);
                    break;
                case "update":
                    updateUser(request, response);
                    break;
                case "confirm":
                    updateMyPassword(request, response);
                    break;
                default:
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    private void searchUser(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        String id = request.getParameter("usernameSearch");
        User existingUser = userDAO.selectUser(id, request);
        listProgramme = programmeDAO.selectAllProgrammes(request);
        request.setAttribute("listProgramme", listProgramme);

        if (existingUser.getRoleID() == 3) {
            student = studentDAO.selectStudent(existingUser.getUsername(), request);
            request.setAttribute("studentProgrammeID", student.getProgrammeID());
        }
        
        RequestDispatcher dispatcher = request.getRequestDispatcher("editUser.jsp");
        request.setAttribute("user", existingUser);
        dispatcher.forward(request, response);

    }

    private void insertUser(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String username = request.getParameter("username");
        String name = request.getParameter("name");
        String surname = request.getParameter("surname");
        String email = request.getParameter("email");
        String cellNo = request.getParameter("cellNo");
        String password = "password";
        int roleID = Integer.parseInt(request.getParameter("roleID"));
        boolean isDisabled = false;
        User newUser = new User(username, name, surname, email, cellNo, roleID, isDisabled, password);
        userDAO.insertUser(newUser, request);
    }

    private void updateUser(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        String username = request.getParameter("username");
        String name = request.getParameter("name");
        String surname = request.getParameter("surname");
        String email = request.getParameter("email");
        String cellNo = request.getParameter("cellNo");
        int roleID = Integer.parseInt(request.getParameter("roleID"));
        boolean isDisabled = false;
        if(request.getParameter("isUserEnabled")!=null){
            isDisabled = true;
        }

        User updateUserInfo = new User(username, name, surname, email, cellNo, roleID, isDisabled);
        userDAO.updateUser(updateUserInfo, request);

        if (roleID == 3) {
            int programmeID = Integer.parseInt(request.getParameter("programmeDrop"));
            student.setProgrammeID(programmeID);
            studentDAO.updateStudent(student, request);
        }
        RequestDispatcher dispatcher = request.getRequestDispatcher("editUser.jsp");
        request.setAttribute("messageLbl", "User updated");
        dispatcher.forward(request, response);
    }

    private void updateMyPassword(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        String username = request.getParameter("username");
        String password1 = request.getParameter("password1");
        String password2 = request.getParameter("password2");
        if (password1.equals(password2)) {
            User updateUserInfo = new User();
            updateUserInfo.setUsername(username);
            updateUserInfo.setPassword(password1);
            userDAO.updateMyPassword(updateUserInfo, request);
            RequestDispatcher dispatcher = request.getRequestDispatcher("updatePassword.jsp");
            request.setAttribute("messageLbl", "password updated");
            dispatcher.forward(request, response);

        } else {
            RequestDispatcher dispatcher = request.getRequestDispatcher("updatePassword.jsp");
            request.setAttribute("messageLbl", "passwords do nont match");
            dispatcher.forward(request, response);
        }

    }

}
