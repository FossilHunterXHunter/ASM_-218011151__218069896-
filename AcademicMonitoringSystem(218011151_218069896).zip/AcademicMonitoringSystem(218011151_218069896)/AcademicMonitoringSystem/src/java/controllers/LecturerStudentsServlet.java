/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import dataAccessLayer.LecturerModuleDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import repo.User;

/**
 *
 * @author Student
 */
public class LecturerStudentsServlet extends HttpServlet {

    private LecturerModuleDAO lecturerModuleDAO;
    List<?> listModule = null;

    public void init() {
        lecturerModuleDAO = new LecturerModuleDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            searchLecturerModulesByUserID(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(UserModulesServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("pathAction");

        try {
            switch (action) {

                case "search":
                    searchEnrolledStudents(request, response);
                    break;

                default:
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    private void searchLecturerModulesByUserID(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        HttpSession session = request.getSession();
        String lid = (String) session.getAttribute("username");
        //    List<LecturerModule> lists = lecturerModuleDAO.selectLecturerModuleByUserID(lid,request);
        listModule = lecturerModuleDAO.selectLecturerModuleByUserID(lid, request);
        request.setAttribute("listModule", listModule);
        RequestDispatcher dispatcher = request.getRequestDispatcher("enrolledStudents.jsp");
        dispatcher.forward(request, response);
    }

    private void searchEnrolledStudents(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        int mid = Integer.parseInt(request.getParameter("moduleDrop"));
        List<User> students = lecturerModuleDAO.selectEnrolledStudents(mid, request);
        request.setAttribute("students", students);
        request.setAttribute("listModule", listModule);
        request.setAttribute("moduleID", mid);
        RequestDispatcher dispatcher = request.getRequestDispatcher("enrolledStudents.jsp");
        dispatcher.forward(request, response);
    }

}
