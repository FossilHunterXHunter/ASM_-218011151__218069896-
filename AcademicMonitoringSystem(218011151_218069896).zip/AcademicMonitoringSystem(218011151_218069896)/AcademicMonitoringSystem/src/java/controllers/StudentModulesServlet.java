/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import dataAccessLayer.StudentModulesDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import repo.StudentModules;

/**
 *
 * @author Student
 */
public class StudentModulesServlet extends HttpServlet {

    private StudentModulesDAO studentModulesDAO;

    public void init() {
        studentModulesDAO = new StudentModulesDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("pathAction");

        try {
            switch (action) {
                case "insert":
                    insertStudentModules(request, response);
                    break;
                case "search":
                    searchStudentModules(request, response);
                    break;
                case "update":
                    updateStudentModules(request, response);
                    break;
                case "list":
                    listStudentModules(request, response);
                    break;
                default:
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    private void searchStudentModules(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("idSearch"));
        StudentModules existingsearchStudentModules = studentModulesDAO.selectStudentModules(id, request);
        request.setAttribute("existingsearchStudentModules", existingsearchStudentModules);

    }

    private void insertStudentModules(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String StudentID = request.getParameter("StudentID");
        int ModuleID = Integer.parseInt(request.getParameter("ModuleID"));
        int Year = Integer.parseInt(request.getParameter("Year"));
        int Semester = Integer.parseInt(request.getParameter("Semester"));
        StudentModules newStudentModules = new StudentModules(StudentID, ModuleID, Year, Semester);
        studentModulesDAO.insertStudentModules(newStudentModules, request);
    }

    private void updateStudentModules(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("ID"));
        String StudentID = request.getParameter("StudentID");
        int ModuleID = Integer.parseInt(request.getParameter("ModuleID"));
        int Year = Integer.parseInt(request.getParameter("Year"));
        int Semester = Integer.parseInt(request.getParameter("Semester"));
        StudentModules updateStudentModules = new StudentModules(id, StudentID, ModuleID, Year, Semester);
        studentModulesDAO.updateStudentModules(updateStudentModules, request);
    }

    private void listStudentModules(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<StudentModules> listStudentModules = studentModulesDAO.selectAllStudentModules(request);
        request.setAttribute("listStudentModules", listStudentModules);
    }

}
