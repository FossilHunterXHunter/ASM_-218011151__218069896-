/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import dataAccessLayer.StudentDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import repo.Student;

/**
 *
 * @author Student
 */
public class StudentServlet extends HttpServlet {

    private StudentDAO studentDAO;

    public void init() {
        studentDAO = new StudentDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("pathAction");

        try {
            switch (action) {
                case "insert":
                    insertStudent(request, response);
                    break;
                case "search":
                    searchStudent(request, response);
                    break;
                case "update":
                    updateStudent(request, response);
                    break;
                case "list":
                    listStudent(request, response);
                    break;
                default:
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    private void searchStudent(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        String id = request.getParameter("idSearch");
        Student existingsearchStudent = studentDAO.selectStudent(id, request);
        RequestDispatcher dispatcher = request.getRequestDispatcher("admin/manageStudent.jsp");
        // request.setAttribute("student", existingsearchStudent);
        //   dispatcher.forward(request, response);

    }

    private void insertStudent(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String studentID = request.getParameter("studentID");
        int programmeID = Integer.parseInt(request.getParameter("programmeID"));
        int termConditionID = Integer.parseInt(request.getParameter("termConditionID"));
        Student newStudent = new Student(studentID, programmeID, termConditionID);
        studentDAO.insertStudent(newStudent, request);
        // response.sendRedirect("list");
    }

    private void updateStudent(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String studentID = request.getParameter("studentID");
        int programmeID = Integer.parseInt(request.getParameter("credit"));
        int termConditionID = Integer.parseInt(request.getParameter("termConditionID"));
        Student updateStudentInfo = new Student(studentID, programmeID, termConditionID);
        studentDAO.updateStudent(updateStudentInfo, request);
//        response.sendRedirect("list");
    }

    private void listStudent(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<Student> listStudent = studentDAO.selectAllStudents(request);
        request.setAttribute("listStudent", listStudent);
        //  RequestDispatcher dispatcher = request.getRequestDispatcher("admin/manageModules.jsp");
        // dispatcher.forward(request, response);
    }

}
