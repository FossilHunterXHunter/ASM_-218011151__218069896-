/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import dataAccessLayer.CurriculumDAO;
import dataAccessLayer.ProgrammeDAO;
import dataAccessLayer.RegistrationDateDAO;
import dataAccessLayer.StudentDAO;
import dataAccessLayer.StudentModulesDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import repo.Curriculum;
import repo.Programme;
import repo.RegistrationDate;
import repo.Student;
import repo.StudentModules;
import repo.StudentProgressInfo;

/**
 *
 * @author Student
 */
public class RegisterServlet extends HttpServlet {

    private RegistrationDateDAO registrationDateDAO;
    private CurriculumDAO curriculumDAO;
    private StudentDAO studentDAO;
    private StudentModulesDAO studentModulesDAO;
    private ProgrammeDAO programmeDAO;
    List<Curriculum> studentCurriculumsCore1 = new ArrayList<>();
    List<Curriculum> studentCurriculumsElective1 = new ArrayList<>();
    List<Curriculum> studentCurriculumsCore2 = new ArrayList<>();
    List<Curriculum> studentCurriculumsElective2 = new ArrayList<>();
    Student student = null;

    public void init() {
        registrationDateDAO = new RegistrationDateDAO();
        curriculumDAO = new CurriculumDAO();
        studentDAO = new StudentDAO();
        studentModulesDAO = new StudentModulesDAO();
        programmeDAO = new ProgrammeDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {

            HttpSession session = request.getSession();
            String studentID = (String) session.getAttribute("username");
            student = studentDAO.selectStudent(studentID, request);

            if (registrationDateDAO.checkRegistraionOpen(request)) {
                searchRegistrationModules(request, response);
                request.setAttribute("registrationClosed", false);

                int regModules = studentModulesDAO.selectStudentModulesRegisiteredThisYear(student.getStudentID(), request).size();

                if (regModules > 0) {
                    searchStudentModules(request, response);
                    request.setAttribute("registrationComplete", true);
                } else {
                    request.setAttribute("studentCurriculumsCore1", studentCurriculumsCore1);
                    request.setAttribute("studentCurriculumsElective1", studentCurriculumsElective1);

                    request.setAttribute("studentCurriculumsCore2", studentCurriculumsCore2);
                    request.setAttribute("studentCurriculumsElective2", studentCurriculumsElective2);
                }
                RequestDispatcher dispatcher = request.getRequestDispatcher("register.jsp");
                dispatcher.forward(request, response);

            } else {
                searchStudentModules(request, response);
                RequestDispatcher dispatcher = request.getRequestDispatcher("register.jsp");
                request.setAttribute("registrationClosed", true);
                dispatcher.forward(request, response);

            }
        } catch (SQLException ex) {
            Logger.getLogger(RegisterServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("pathAction");

        try {
            switch (action) {
                case "search":
                    searchRegistrationModules(request, response);
                    break;
                case "register":
                    registerStudent(request, response);
                    break;
                default:
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    private void searchRegistrationModules(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {

        studentCurriculumsCore1 = curriculumDAO.selectStudentCurriculum(student, "Core", 1, request);
        studentCurriculumsElective1 = curriculumDAO.selectStudentCurriculum(student, "Elective", 1, request);

        studentCurriculumsCore2 = curriculumDAO.selectStudentCurriculum(student, "Core", 2, request);
        studentCurriculumsElective2 = curriculumDAO.selectStudentCurriculum(student, "Elective", 2, request);

    }

    private void registerStudent(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<Curriculum> studentModuleToAdd = new ArrayList<>();
        Programme programme = programmeDAO.selectProgramme(student.getProgrammeID(), request);
        int creditCount1 = 0;
        int creditCount2 = 0;
        String coReq = "";
        boolean coreNotSelected = false;
        int expectedCredit = programme.getTotalCredits() / (programme.getNumberOfYears() * 2);

        for (int i = 0; i < studentCurriculumsCore1.size(); i++) {
            int id = studentCurriculumsCore1.get(i).getID();
            if (request.getParameter(id + "") != null) {
                studentModuleToAdd.add(studentCurriculumsCore1.get(i));
                creditCount1 += studentCurriculumsCore1.get(i).getModule().getCredit();
                coReq = coReq + studentCurriculumsCore1.get(i).getCorequisite();
            } else {
                coreNotSelected = true;
            }
        }

        for (int i = 0; i < studentCurriculumsElective1.size(); i++) {
            int id = studentCurriculumsElective1.get(i).getID();
            if (request.getParameter(id + "") != null) {
                studentModuleToAdd.add(studentCurriculumsElective1.get(i));
                creditCount1 += studentCurriculumsElective1.get(i).getModule().getCredit();
                coReq = coReq + studentCurriculumsElective1.get(i).getCorequisite();
            }
        }

        for (int i = 0; i < studentCurriculumsCore2.size(); i++) {
            int id = studentCurriculumsCore2.get(i).getID();
            if (request.getParameter(id + "") != null) {
                studentModuleToAdd.add(studentCurriculumsCore2.get(i));
                creditCount2 += studentCurriculumsCore2.get(i).getModule().getCredit();
                coReq = coReq + studentCurriculumsCore2.get(i).getCorequisite();
            } else {
                coreNotSelected = true;
            }
        }

        for (int i = 0; i < studentCurriculumsElective2.size(); i++) {
            int id = studentCurriculumsElective2.get(i).getID();
            if (request.getParameter(id + "") != null) {
                studentModuleToAdd.add(studentCurriculumsElective2.get(i));
                creditCount2 += studentCurriculumsElective2.get(i).getModule().getCredit();
                coReq = coReq + studentCurriculumsElective2.get(i).getCorequisite();
            }
        }

        if (coreNotSelected) {
            request.setAttribute("messageLbl", "All core modules have to be selected");
        } else if ((expectedCredit != creditCount1) || (expectedCredit != creditCount2)) { //Check if correct number of credits s
            request.setAttribute("messageLbl", "Selected modules credit total per semester is not " + expectedCredit);
        } else if (coReq.length() > 2) {//Check if corequisite selected
            String c[] = coReq.split(",");
            int coReqCount = 0;

            for (int j = 0; j < c.length; j++) {
                for (int i = 0; i < studentModuleToAdd.size(); i++) {
                    System.out.println(c[j]);
                    if (c[j].equals(studentModuleToAdd.get(i).getModule().getModuleCode())) {
                        coReqCount++;
                    }
                }
            }

            if (coReqCount != coReq.length()) {
                request.setAttribute("messageLbl", "Corequisite not selected");
            } else {
                studentModulesDAO.insertStudentModules(student, studentModuleToAdd, request);
                request.setAttribute("registrationComplete", true);
            }

        } else {
            studentModulesDAO.insertStudentModules(student, studentModuleToAdd, request);
            request.setAttribute("registrationComplete", true);
        }

        request.setAttribute("studentCurriculumsCore1", studentCurriculumsCore1);
        request.setAttribute("studentCurriculumsElective1", studentCurriculumsElective1);

        request.setAttribute("studentCurriculumsCore2", studentCurriculumsCore2);
        request.setAttribute("studentCurriculumsElective2", studentCurriculumsElective2);

        request.setAttribute("registrationClosed", false);
        searchStudentModules(request, response);
        RequestDispatcher dispatcher = request.getRequestDispatcher("register.jsp");
        dispatcher.forward(request, response);

    }

    private void searchStudentModules(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {

        List<StudentModules> studentModulesList = studentModulesDAO.selectStudentModulesByStudentID(student.getStudentID(), request);

        request.setAttribute("studentModulesList", studentModulesList);

    }

}
