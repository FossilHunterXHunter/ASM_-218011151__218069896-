/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import dataAccessLayer.ModuleDAO;
import dataAccessLayer.ProgrammeDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import repo.Module;

/**
 *
 * @author Student
 */
public class ModuleServlet extends HttpServlet {

    private ModuleDAO moduleDAO;

    public void init() {
        moduleDAO = new ModuleDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("pathAction");

        try {
            switch (action) {
                case "insert":
                    insertModule(request, response);
                    break;
                case "search":
                    searchModule(request, response);
                    break;
                case "update":
                    updateModule(request, response);
                    break;
                case "list":
                    listModules(request, response);
                    break;
                default:
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    private void searchModule(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        String code = request.getParameter("moduleCodeS");
        Module existingsearchModule = moduleDAO.selectModuleByCode(code, request);
        RequestDispatcher dispatcher = request.getRequestDispatcher("manageModules.jsp");
        request.setAttribute("module", existingsearchModule);
        if (existingsearchModule == null) {
            request.setAttribute("messageLbl", "No modules found");
        }
        dispatcher.forward(request, response);

    }

    private void insertModule(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        String moduleName = request.getParameter("moduleName");
        String moduleCode = request.getParameter("moduleCode");
        int credit = Integer.parseInt(request.getParameter("credits"));
     Module newModule = new Module(moduleName, moduleCode, credit);
        moduleDAO.insertModule(newModule, request);
        RequestDispatcher dispatcher = request.getRequestDispatcher("manageModules.jsp");
        request.setAttribute("messageLbl", "Module added");
        dispatcher.forward(request, response);
    }

    private void updateModule(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        int id = Integer.parseInt(request.getParameter("idU"));
        String moduleName = request.getParameter("moduleNameU");
        String moduleCode = request.getParameter("moduleCodeU");
        int credit = Integer.parseInt(request.getParameter("creditsU"));
        Module updateModuleInfo = new Module(id, moduleName, moduleCode, credit);
        moduleDAO.updateModule(updateModuleInfo, request);
        RequestDispatcher dispatcher = request.getRequestDispatcher("manageModules.jsp");
        request.setAttribute("messageLbl", "Module updated");
        dispatcher.forward(request, response);
    }

    private void listModules(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<Module> listModule = moduleDAO.selectAllModules(request);
        request.setAttribute("listModule", listModule);
        RequestDispatcher dispatcher = request.getRequestDispatcher("manageModules.jsp");
        dispatcher.forward(request, response);
    }

}
