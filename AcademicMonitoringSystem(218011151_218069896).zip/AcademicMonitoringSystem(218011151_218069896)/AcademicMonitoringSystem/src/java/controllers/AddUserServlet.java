/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import dataAccessLayer.ProgrammeDAO;
import dataAccessLayer.StudentDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dataAccessLayer.UserDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import repo.Programme;
import repo.Student;
import repo.User;

/**
 *
 * @author Student
 */
public class AddUserServlet extends HttpServlet {

    // private static final long serialVersionUID = 1 L;
    private UserDAO userDAO;
    private StudentDAO studentDAO;
    private ProgrammeDAO programmeDAO;
    List<Programme> listProgramme = new ArrayList<>();

    public void init() {
        userDAO = new UserDAO();
        studentDAO = new StudentDAO();
        programmeDAO = new ProgrammeDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        listProgramme = programmeDAO.selectAllProgrammes(request);
        request.setAttribute("listProgramme", listProgramme);
        RequestDispatcher dispatcher = request.getRequestDispatcher("addUser.jsp");
        dispatcher.forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("pathAction");

        try {
            switch (action) {
                case "insert":
                    insertUser(request, response);
                    break;
                default:
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    private void insertUser(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        String username = request.getParameter("username");
        String name = request.getParameter("name");
        String surname = request.getParameter("surname");
        String email = request.getParameter("email");
        String cellNo = request.getParameter("cellNo");
        String password = "password";
        int roleID = Integer.parseInt(request.getParameter("roleID"));
        boolean isDisabled = false;
        User newUser = new User(username, name, surname, email, cellNo, roleID, isDisabled, password);
        userDAO.insertUser(newUser, request);

        if (roleID == 3) {
            int programmeID = Integer.parseInt(request.getParameter("programmeDrop"));
            int termConditionID = 1;
            Student newStudent = new Student(username, programmeID, termConditionID);
            studentDAO.insertStudent(newStudent, request);
        }
        request.setAttribute("listProgramme", listProgramme);
        RequestDispatcher dispatcher = request.getRequestDispatcher("addUser.jsp");
        request.setAttribute("messageLbl", "User added");
        dispatcher.forward(request, response);

    }

}
