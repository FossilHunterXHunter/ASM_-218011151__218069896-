/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataAccessLayer;

import com.mysql.cj.Session;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import repo.User;

/**
 *
 * @author Student
 */
public class UserDAO {

    private static final String INSERT_USERS_SQL = "INSERT INTO user"
            + "  (Username, Name, Surname, Email, PhoneNumber, RoleID, Password, isDisabled)"
            + " VALUES (?, ?, ?, ?, ?, ?, ?, ?);";
    private static final String SELECT_USER_BY_ID = "select * from user where Username =?";
    private static final String SELECT_ALL_USERS = "select * from user";
    private static final String UPDATE_USER_SQL = "update user set Name = ?,Surname= ?, Email =?, PhoneNumber =?, RoleID=?, isDisabled=? where Username = ?;";
    private static final String DISABLE_USER = "update user set isDisabled =? where Username = ?;";
    private static final String UPDATE_MY_PASSWORD = "update user set password =? where Username = ?;";

    public UserDAO() {
    }

    protected Connection getConnection(HttpServletRequest request) {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(request.getServletContext().getInitParameter("dbURL"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return connection;
    }

    public void insertUser(User user, HttpServletRequest request) throws SQLException {
        System.out.println(INSERT_USERS_SQL);
        // try-with-resource statement will auto close the connection.
        try (Connection connection = getConnection(request); PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
            preparedStatement.setString(1, user.getUsername());
            preparedStatement.setString(2, user.getName());
            preparedStatement.setString(3, user.getSurname());
            preparedStatement.setString(4, user.getEmail());
            preparedStatement.setString(5, user.getCellNo());
            preparedStatement.setInt(6, user.getRoleID());
            preparedStatement.setString(7, user.getPassword());
            preparedStatement.setBoolean(8, user.getIsDisabled());
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    public User selectUser(String id, HttpServletRequest request) {
        User user = null;
        // Step 1: Establishing a Connection
        try (Connection connection = getConnection(request);
                // Step 2:Create a statement using connection object
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_USER_BY_ID);) {
            preparedStatement.setString(1, id);
            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            ResultSet rs = preparedStatement.executeQuery();

            // Step 4: Process the ResultSet object.
            while (rs.next()) {
                String username = rs.getString("username");
                String name = rs.getString("name");
                String surname = rs.getString("surname");
                String email = rs.getString("email");
                String cellNo = rs.getString("PhoneNumber");
                int roleID = Integer.parseInt(rs.getString("roleID"));
                boolean isDisabled = rs.getBoolean("isDisabled");
         
                user = new User(username, name, surname, email, cellNo, roleID, isDisabled);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return user;
    }

    public boolean updateUser(User user, HttpServletRequest request) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = getConnection(request); PreparedStatement statement = connection.prepareStatement(UPDATE_USER_SQL);) {
            statement.setString(7, user.getUsername());
            statement.setString(1, user.getName());
            statement.setString(2, user.getSurname());
            statement.setString(3, user.getEmail());
            statement.setString(4, user.getCellNo());
            statement.setInt(5, user.getRoleID());
            statement.setBoolean(6, user.getIsDisabled());

            System.out.println(statement);
            
            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    public boolean updateMyPassword(User user, HttpServletRequest request) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = getConnection(request); PreparedStatement statement = connection.prepareStatement(UPDATE_MY_PASSWORD);) {
            statement.setString(2, user.getUsername());
            statement.setString(1, user.getPassword());

            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }

}
