/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataAccessLayer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import repo.Curriculum;
import repo.Module;
import repo.Programme;
import repo.Student;
import repo.StudentModules;
import repo.StudentProgressInfo;

/**
 *
 * @author Student
 */
public class CurriculumDAO {

    private static final String INSERT_CURRICULUM_SQL = "INSERT INTO Curriculum"
            + "  (ProgrammeID, Year, Semester, ModuleID, ModuleType, Prerequisite, Corequisite)"
            + " VALUES (?, ?, ?, ?, ?, ?, ?);";
    private static final String SELECT_CURRICULUM_BY_ID = "select * from Curriculum where ID =?";
    private static final String SELECT_ALL_CURRICULUMS = "select * from Curriculum";
    private static final String UPDATE_CURRICULUM_SQL = "update Curriculum set ProgrammeID = ?,Semester= ?, ModuleID =?, ModuleType=?, Year=?, Prerequisite=?, Corequisite=? where ID = ?;";

    public CurriculumDAO() {
    }

    protected Connection getConnection(HttpServletRequest request) {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(request.getServletContext().getInitParameter("dbURL"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return connection;
    }

    public void insertCurriculum(Curriculum curriculum, HttpServletRequest request) throws SQLException {
        System.out.println(INSERT_CURRICULUM_SQL);
        try (Connection connection = getConnection(request); PreparedStatement preparedStatement = connection.prepareStatement(INSERT_CURRICULUM_SQL)) {
            preparedStatement.setInt(1, curriculum.getProgrammeID());
            preparedStatement.setInt(2, curriculum.getYear());
            preparedStatement.setInt(3, curriculum.getSemester());
            preparedStatement.setInt(4, curriculum.getModuleID());
            preparedStatement.setString(5, curriculum.getModuleType());
            preparedStatement.setString(6, curriculum.getPrerequisite());
            preparedStatement.setString(7, curriculum.getCorequisite());
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    public List<Curriculum> selectAllCurriculumsByProgrammeName(String programmeName, HttpServletRequest request) {
        ProgrammeDAO programmeDAO = new ProgrammeDAO();
        Programme programme = programmeDAO.selectProgrammeByName(programmeName, request);
        List<Curriculum> curriculums = new ArrayList<>();
        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement("select * from Curriculum where ProgrammeID =" + programme.getID());) {

            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int id = Integer.parseInt(rs.getString("ID"));
                int ProgrammeID = Integer.parseInt(rs.getString("ProgrammeID"));
                int Year = Integer.parseInt(rs.getString("Year"));
                int Semester = Integer.parseInt(rs.getString("Semester"));
                int ModuleID = Integer.parseInt(rs.getString("ModuleID"));
                String ModuleType = rs.getString("ModuleType");
                String Prerequisite = rs.getString("Prerequisite");
                String Corequisite = rs.getString("Corequisite");

                curriculums.add(new Curriculum(id, ProgrammeID, Year, Semester, ModuleID, ModuleType, Prerequisite, Corequisite));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return curriculums;
    }

    public List<Curriculum> selectAllCurriculumsByProgrammeID(int pID, HttpServletRequest request) {
        List<Curriculum> curriculums = new ArrayList<>();
        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement("select * from Curriculum where ProgrammeID =" + pID);) {

            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int id = Integer.parseInt(rs.getString("ID"));
                int ProgrammeID = Integer.parseInt(rs.getString("ProgrammeID"));
                int Year = Integer.parseInt(rs.getString("Year"));
                int Semester = Integer.parseInt(rs.getString("Semester"));
                int ModuleID = Integer.parseInt(rs.getString("ModuleID"));
                String ModuleType = rs.getString("ModuleType");
                String Prerequisite = rs.getString("Prerequisite");
                String Corequisite = rs.getString("Corequisite");

                curriculums.add(new Curriculum(id, ProgrammeID, Year, Semester, ModuleID, ModuleType, Prerequisite, Corequisite));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return curriculums;
    }

    public Curriculum selectModuleCurriculum(int pID, int mID, HttpServletRequest request) {
        Curriculum curriculum = null;
        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement("select * from Curriculum "
                        + " where ProgrammeID =" + pID
                        + " and ModuleID =" + mID);) {

            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int id = Integer.parseInt(rs.getString("ID"));
                int ProgrammeID = Integer.parseInt(rs.getString("ProgrammeID"));
                int Year = Integer.parseInt(rs.getString("Year"));
                int Semester = Integer.parseInt(rs.getString("Semester"));
                int ModuleID = Integer.parseInt(rs.getString("ModuleID"));
                String ModuleType = rs.getString("ModuleType");
                String Prerequisite = rs.getString("Prerequisite");
                String Corequisite = rs.getString("Corequisite");

                curriculum = new Curriculum(id, ProgrammeID, Year, Semester, ModuleID, ModuleType, Prerequisite, Corequisite);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return curriculum;
    }

    public boolean checkIfModuleSemesterOne(int pID, String req, HttpServletRequest request) {
        boolean isInSemester = false;
        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement("select * from Curriculum where "
                        + "ProgrammeID =" + pID
                        + " and Semester=1 and ModuleID IN(SELECT ID from Module where ModuleCode IN(" + req + "))");) {

            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                isInSemester = true;
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return isInSemester;
    }

    public List<Curriculum> selectStudentCurriculum(Student student, String modType, int semester, HttpServletRequest request) {

        List<Curriculum> studentCurriculums = new ArrayList<>();
        int year = 0;
        if (student.getTotalSemesters() % 2 != 0) {
            year = ((student.getTotalSemesters() + 1) / 2) + 1;
        } else {
            year = (student.getTotalSemesters() / 2) + 1;
        }
        System.out.println("Getting curriculum for year : " + year);
        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement("select * from Curriculum "
                        + "Inner join asm.module "
                        + "on module.ID = Curriculum.moduleID where ModuleID "
                        + " NOT IN (SELECT MODULEID FROM StudentModule WHERE Passed = 1  AND StudentID = '"
                        + student.getStudentID() + "') "
                        + "AND ModuleID NOT IN (SELECT ModuleID FROM asm.Curriculum WHERE ModuleType='Elective' AND year<" + year + ")"
                        + "AND ProgrammeID ="
                        + student.getProgrammeID() + " AND ModuleType = '" + modType + "' and Semester =" + semester + " and Curriculum.year<=" + year);) {

            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {

                boolean passPre = false;

                int id = Integer.parseInt(rs.getString(1));
                int ProgrammeID = Integer.parseInt(rs.getString("ProgrammeID"));
                int Year = Integer.parseInt(rs.getString(3));
                int Semester = Integer.parseInt(rs.getString("Semester"));
                int ModuleID = Integer.parseInt(rs.getString("ModuleID"));
                String ModuleType = rs.getString("ModuleType");
                String Prerequisite = rs.getString("Prerequisite");
                String Corequisite = rs.getString("Corequisite");

                String ModuleName = rs.getString("ModuleName");
                String ModuleCode = rs.getString("ModuleCode");
                int Credit = Integer.parseInt(rs.getString("Credit"));

                Module module = new Module(ModuleID, ModuleName, ModuleCode, Credit);
                if (Prerequisite != null && Prerequisite.length() > 1) {
                    String pre = Prerequisite.replace(",", "','");
                    pre = pre.substring(2, pre.length());
                    pre = pre + "'";

                    StudentModulesDAO studentModulesDAO = new StudentModulesDAO();
                    List<StudentModules> sm = studentModulesDAO.selectRequisitesPassed(student, pre, request);
                    String countPre[] = pre.split(",");
                    if (sm.size() == countPre.length) {
                        passPre = true;
                    } else if ((semester == 2) && (checkIfModuleSemesterOne(ProgrammeID, pre, request))) {
                        passPre = true;
                    }
                } else {
                    passPre = true;
                }

                if (passPre) {
                    studentCurriculums.add(new Curriculum(id, ProgrammeID, Year, Semester, ModuleID, ModuleType, Prerequisite, Corequisite, module));
                }
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return studentCurriculums;
    }

    public boolean updateCurriculum(Curriculum curriculum, HttpServletRequest request) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = getConnection(request); PreparedStatement statement = connection.prepareStatement(UPDATE_CURRICULUM_SQL);) {
            statement.setInt(8, curriculum.getID());

            statement.setInt(1, curriculum.getProgrammeID());
            statement.setInt(2, curriculum.getSemester());
            statement.setInt(3, curriculum.getModuleID());
            statement.setString(4, curriculum.getModuleType());
            statement.setInt(5, curriculum.getYear());
            statement.setString(6, curriculum.getPrerequisite());
            statement.setString(7, curriculum.getCorequisite());

            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }

}
