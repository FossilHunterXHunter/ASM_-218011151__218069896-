/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataAccessLayer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import repo.AssessmentType;
import repo.MinCollegeRequirements;
import repo.StudentProgressInfo;

/**
 *
 * @author Student
 */
public class MinCollegeReqDAO {

    private static final String INSERT_SQL = "INSERT INTO collegerequirements"
            + "  (MinCredits, NoSemestersCompleted, College, NoYearQualification)"
            + " VALUES (?, ?,?, ?);";
    private static final String SELECT_BY_ID = "select * from collegerequirements where ID =?";
    private static final String SELECT_ALL = "select * from collegerequirements";
    private static final String UPDATE_SQL = "update collegerequirements set MinCredits = ?,NoSemestersCompleted= ?, College=?, NoYearQualification =? where ID = ?;";

    public MinCollegeReqDAO() {
    }

    protected Connection getConnection(HttpServletRequest request) {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(request.getServletContext().getInitParameter("dbURL"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return connection;
    }

    public void insertMinCollegeReq(MinCollegeRequirements mcr, HttpServletRequest request) throws SQLException {
        System.out.println(INSERT_SQL);
        try (Connection connection = getConnection(request); PreparedStatement preparedStatement = connection.prepareStatement(INSERT_SQL)) {
            preparedStatement.setInt(1, mcr.getMinCredits());
            preparedStatement.setInt(2, mcr.getNoSemestersCompleted());
            preparedStatement.setString(3, mcr.getCollege());
            preparedStatement.setInt(4, mcr.getNoYearQualification());
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    public MinCollegeRequirements selectMinCollegeReq(int id, HttpServletRequest request) {
        MinCollegeRequirements mcr = null;
        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_BY_ID);) {
            preparedStatement.setInt(1, id);
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {

                int MinCredits = Integer.parseInt(rs.getString("MinCredits"));
                int NoSemestersCompleted = Integer.parseInt(rs.getString("NoSemestersCompleted"));
                String College = rs.getString("College");
                int NoYearQualification = Integer.parseInt(rs.getString("NoYearQualification"));
                mcr = new MinCollegeRequirements(id, MinCredits, NoSemestersCompleted, College, NoYearQualification);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return mcr;
    }

    public List<MinCollegeRequirements> selectAllMinCollegeRequirements(HttpServletRequest request) {
        List<MinCollegeRequirements> mcrs = new ArrayList<>();
        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL);) {
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int id = Integer.parseInt(rs.getString("ID"));
                int MinCredits = Integer.parseInt(rs.getString("MinCredits"));
                int NoSemestersCompleted = Integer.parseInt(rs.getString("NoSemestersCompleted"));
                String College = rs.getString("College");
                int NoYearQualification = Integer.parseInt(rs.getString("NoYearQualification"));
                mcrs.add(new MinCollegeRequirements(id, MinCredits, NoSemestersCompleted, College, NoYearQualification));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return mcrs;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }

}
