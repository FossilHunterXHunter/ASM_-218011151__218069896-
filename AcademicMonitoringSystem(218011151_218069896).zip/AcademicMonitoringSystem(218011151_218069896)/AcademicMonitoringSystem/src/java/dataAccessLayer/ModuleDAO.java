/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataAccessLayer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import repo.Module;

/**
 *
 * @author Student
 */
public class ModuleDAO {

    private static final String INSERT_MODULE_SQL = "INSERT INTO Module"
            + "  (ModuleName, ModuleCode, Credit)"
            + " VALUES (?, ?, ?);";
    private static final String SELECT_MODULE_BY_ID = "select * from Module where ID =?";
    private static final String SELECT_MODULE_BY_CODE = "select * from Module where ModuleCode =?";
    private static final String SELECT_ALL_MODULES = "select * from Module";
    private static final String UPDATE_MODULE_SQL = "update Module set ModuleName = ?,ModuleCode= ?, Credit =? where ID = ?;";

    public ModuleDAO() {
    }

    protected Connection getConnection(HttpServletRequest request) {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(request.getServletContext().getInitParameter("dbURL"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return connection;
    }

    public void insertModule(Module module, HttpServletRequest request) throws SQLException {
        System.out.println(INSERT_MODULE_SQL);
        try (Connection connection = getConnection(request); PreparedStatement preparedStatement = connection.prepareStatement(INSERT_MODULE_SQL)) {
            preparedStatement.setString(1, module.getModuleName());
            preparedStatement.setString(2, module.getModuleCode());
            preparedStatement.setInt(3, module.getCredit());
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    public Module selectModule(int id, HttpServletRequest request) {
        Module module = null;
        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_MODULE_BY_ID);) {
            preparedStatement.setInt(1, id);
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                String moduleName = rs.getString("ModuleName");
                String moduleCode = rs.getString("ModuleCode");
                int credit = Integer.parseInt(rs.getString("Credit"));
                module = new Module(id, moduleName, moduleCode, credit);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return module;
    }

    public Module selectModuleByCode(String code, HttpServletRequest request) {
        Module module = null;
        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_MODULE_BY_CODE);) {
            preparedStatement.setString(1, code);
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("ID");
                String moduleName = rs.getString("ModuleName");
                int credit = Integer.parseInt(rs.getString("Credit"));
 
                module = new Module(id, moduleName, code, credit);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return module;
    }

    public boolean updateModule(Module module, HttpServletRequest request) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = getConnection(request); PreparedStatement statement = connection.prepareStatement(UPDATE_MODULE_SQL);) {
            statement.setInt(4, module.getID());
            statement.setString(1, module.getModuleName());
            statement.setString(2, module.getModuleCode());
            statement.setInt(3, module.getCredit());
            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    public List<Module> selectAllModules(HttpServletRequest request) {

        List<Module> modules = new ArrayList<>();

        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_MODULES);) {
            System.out.println(preparedStatement);

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("ID");
                String moduleName = rs.getString("ModuleName");
                String moduleCode = rs.getString("ModuleCode");
                int credit = Integer.parseInt(rs.getString("Credit"));

                modules.add(new Module(id, moduleName, moduleCode, credit));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return modules;
    }

    public List<Module> searchModuleByCode(String code, HttpServletRequest request) {
        List<Module> modules = new ArrayList<>();
        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement("select * from module where ModuleCode like '%" + code + "%'");) {
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("ID");
                String moduleName = rs.getString("ModuleName");
                String moduleCode = rs.getString("ModuleCode");
                int credit = Integer.parseInt(rs.getString("Credit"));
                modules.add(new Module(id, moduleName, moduleCode, credit));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return modules;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
