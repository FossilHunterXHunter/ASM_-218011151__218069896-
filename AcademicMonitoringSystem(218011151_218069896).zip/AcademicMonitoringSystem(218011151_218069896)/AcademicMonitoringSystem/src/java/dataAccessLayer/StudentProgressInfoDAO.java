/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataAccessLayer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.Part;
import repo.AssessmentType;
import repo.Curriculum;
import repo.Module;
import repo.StudentModules;
import repo.StudentProgressInfo;
import repo.User;

/**
 *
 * @author Student
 */
public class StudentProgressInfoDAO {

    private static final String INSERT_SQL = "INSERT INTO StudentProgressInfo"
            + "  (StudentID, StudentModuleID, AssessmentTypeID, AssessmentDescription, Mark, Date)"
            + " VALUES (?, ?, ?, ?, ?, DATE(NOW()));";
    private static final String SELECT_BY_ID = "select * from StudentProgressInfo where ID =?";
    private static final String SELECT_ALL = "select * from StudentProgressInfo";
    private static final String UPDATE_SQL = "update StudentProgressInfo set StudentID = ?,StudentModuleID= ?, AssessmentTypeID =?, AssessmentDescription=?, Mark=?, Date=? where ID = ?;";

    public StudentProgressInfoDAO() {
    }

    protected Connection getConnection(HttpServletRequest request) {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(request.getServletContext().getInitParameter("dbURL"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return connection;
    }

    public void insertStudentProgressInfo(StudentProgressInfo studentProgressInfo, HttpServletRequest request) throws SQLException {
        System.out.println(INSERT_SQL);
        try (Connection connection = getConnection(request); PreparedStatement preparedStatement = connection.prepareStatement(INSERT_SQL)) {
            preparedStatement.setString(1, studentProgressInfo.getStudentID());
            preparedStatement.setInt(2, studentProgressInfo.getStudentModuleID());
            preparedStatement.setInt(3, studentProgressInfo.getAssessmentTypeID());
            preparedStatement.setString(4, studentProgressInfo.getAssessmentDescription());
            preparedStatement.setInt(5, studentProgressInfo.getMark());
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    public void insertStudentProgressInfoCSV(Part filePart, int ModuleID, int AssessmentTypeID, int Semester, String AssessmentDescription, HttpServletRequest request) throws SQLException {

        try {
            InputStream fileContent = filePart.getInputStream();
            InputStreamReader inputStreamReader = new InputStreamReader(fileContent);
            BufferedReader csvReader = new BufferedReader(inputStreamReader);
            String row = "";

            Connection connection = getConnection(request);
            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_SQL);

            StudentModulesDAO studentModulesDAO = new StudentModulesDAO();
            StudentModules sm = new StudentModules();
            while ((row = csvReader.readLine()) != null) {
                row = row.replace("ï»¿", "");
                String[] data = row.split(",");
                sm.setStudentID(data[0]);
                sm.setModuleID(ModuleID);
                sm.setSemester(Semester);
                int smID = studentModulesDAO.selectStudentModuleID(sm, request);

                preparedStatement.setString(1, data[0]);
                preparedStatement.setInt(2, smID);
                preparedStatement.setInt(3, AssessmentTypeID);
                preparedStatement.setString(4, AssessmentDescription);
                preparedStatement.setInt(5, Integer.parseInt(data[1]));

                System.out.println(preparedStatement);
                preparedStatement.executeUpdate();

            }
            csvReader.close();

        } catch (Exception ex) {
            Logger.getLogger(StudentProgressInfoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public StudentProgressInfo selectStudentProgressInfo(int id, HttpServletRequest request) {
        StudentProgressInfo studentProgressInfo = null;
        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_BY_ID);) {
            preparedStatement.setInt(1, id);
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                String StudentID = rs.getString("StudentID");
                int StudentModuleID = Integer.parseInt(rs.getString("StudentModuleID"));
                int AssessmentTypeID = Integer.parseInt(rs.getString("AssessmentTypeID"));
                String AssessmentDescription = rs.getString("AssessmentDescription");
                int Mark = Integer.parseInt(rs.getString("Mark"));
                String Date = rs.getString("Date");
                studentProgressInfo = new StudentProgressInfo(id, StudentID, StudentModuleID, AssessmentTypeID, AssessmentDescription, Mark, Date);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return studentProgressInfo;
    }

    public List<AssessmentType> selectAllAssessmentType(HttpServletRequest request) {
        List<AssessmentType> assessmentTypes = new ArrayList<>();
        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement("Select * from AssessmentType");) {
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int id = Integer.parseInt(rs.getString("ID"));
                String MarkDescription = rs.getString("MarkDescription");
                assessmentTypes.add(new AssessmentType(id, MarkDescription));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return assessmentTypes;
    }

    public boolean updateStudentProgressInfo(StudentProgressInfo studentProgressInfo, HttpServletRequest request) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = getConnection(request); PreparedStatement statement = connection.prepareStatement(UPDATE_SQL);) {
            statement.setInt(7, studentProgressInfo.getID());
            statement.setString(1, studentProgressInfo.getStudentID());
            statement.setInt(2, studentProgressInfo.getStudentModuleID());
            statement.setInt(3, studentProgressInfo.getAssessmentTypeID());
            statement.setString(4, studentProgressInfo.getAssessmentDescription());
            statement.setInt(5, studentProgressInfo.getMark());
            statement.setString(6, studentProgressInfo.getDate());
            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    public List<StudentProgressInfo> selectAllStudentsByModule(int mid, int semester, HttpServletRequest request) {

        List<StudentProgressInfo> studentProgressInfo = new ArrayList<>();
        User student = null;
        AssessmentType assessmentType = null;
        Module module = null;
        StudentModules studentModule = null;

        try (Connection connection = getConnection(request);
                Statement stmt = connection.createStatement();) {
            // System.out.println(preparedStatement);

            ResultSet rs = stmt.executeQuery("SELECT * FROM studentprogressinfo "
                    + "inner join StudentModule "
                    + "on StudentModule.ID = studentprogressinfo.studentModuleID "
                    + "inner join User "
                    + "on User.Username = studentprogressinfo.StudentID "
                    + "inner join AssessmentType "
                    + "on AssessmentType.ID = studentprogressinfo.AssessmentTypeID "
                    + "inner join asm.Module "
                    + "on Module.ID = StudentModule.ModuleID "
                    + "where StudentModule.Year = YEAR(NOW()) and  "
                    + "StudentModule.ModuleID = " + mid + " and StudentModule.Semester = " + semester);

            while (rs.next()) {
                int id = rs.getInt(1);
                String StudentID = rs.getString(7);
                int StudentModuleID = Integer.parseInt(rs.getString(2));
                int AssessmentTypeID = Integer.parseInt(rs.getString(3));
                String AssessmentDescription = rs.getString(5);
                int Mark = Integer.parseInt(rs.getString(4));
                String Date = rs.getString(6);

                int smID = rs.getInt(8);
                int ModuleID = Integer.parseInt(rs.getString(9));
                int Year = Integer.parseInt(rs.getString(10));
                int Semester = Integer.parseInt(rs.getString(12));
                int Pass = Integer.parseInt(rs.getString(13));
                studentModule = new StudentModules(smID, StudentID, ModuleID, Year, Semester, Pass);

                String username = rs.getString(14);
                String name = rs.getString(15);
                String surname = rs.getString(16);
                String email = rs.getString(17);
                String cellNo = rs.getString(18);
                int roleID = Integer.parseInt(rs.getString(19));
                boolean isDisabled = Boolean.parseBoolean(rs.getString(21));
                student = new User(username, name, surname, email, cellNo, roleID, isDisabled);

                int aID = rs.getInt(22);
                String markDescription = rs.getString(23);

                assessmentType = new AssessmentType(aID, markDescription);

                int modID = rs.getInt(24);
                String moduleName = rs.getString(25);
                String code = rs.getString(26);
                int credit = Integer.parseInt(rs.getString(27));
                module = new Module(modID, moduleName, code, credit);

                studentProgressInfo.add(new StudentProgressInfo(id, StudentID, StudentModuleID, AssessmentTypeID, AssessmentDescription, Mark, Date, student, assessmentType, studentModule, module));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return studentProgressInfo;
    }

    public List<StudentProgressInfo> selectStudentMarksByStudentModuleID(int studentModID, HttpServletRequest request) {
        List<StudentProgressInfo> studentProgressInfo = new ArrayList<>();
        User student = null;
        AssessmentType assessmentType = null;
        Module module = null;
        StudentModules studentModule = null;

        try (Connection connection = getConnection(request);
                Statement stmt = connection.createStatement();) {

            ResultSet rs = stmt.executeQuery("SELECT * FROM studentprogressinfo "
                    + "inner join StudentModule "
                    + "on StudentModule.ID = studentprogressinfo.studentModuleID "
                    + "inner join User "
                    + "on User.Username = studentprogressinfo.StudentID "
                    + "inner join AssessmentType "
                    + "on AssessmentType.ID = studentprogressinfo.AssessmentTypeID "
                    + "inner join asm.Module "
                    + "on Module.ID = StudentModule.ModuleID "
                    + "where StudentModuleID = " + studentModID);

            while (rs.next()) {
                int id = rs.getInt(1);
                String StudentID = rs.getString(7);
                int StudentModuleID = Integer.parseInt(rs.getString(2));
                int AssessmentTypeID = Integer.parseInt(rs.getString(3));
                String AssessmentDescription = rs.getString(5);
                int Mark = Integer.parseInt(rs.getString(4));
                String Date = rs.getString(6);

                int smID = rs.getInt(8);
                int ModuleID = Integer.parseInt(rs.getString(9));
                int Year = Integer.parseInt(rs.getString(10));
                int Semester = Integer.parseInt(rs.getString(12));
                int Pass = Integer.parseInt(rs.getString(13));
                studentModule = new StudentModules(smID, StudentID, ModuleID, Year, Semester, Pass);

                String username = rs.getString(14);
                String name = rs.getString(15);
                String surname = rs.getString(16);
                String email = rs.getString(17);
                String cellNo = rs.getString(18);
                int roleID = Integer.parseInt(rs.getString(19));
                boolean isDisabled = Boolean.parseBoolean(rs.getString(21));
                student = new User(username, name, surname, email, cellNo, roleID, isDisabled);

                int aID = rs.getInt(22);
                String markDescription = rs.getString(23);

                assessmentType = new AssessmentType(aID, markDescription);

                int modID = rs.getInt(24);
                String moduleName = rs.getString(25);
                String code = rs.getString(26);
                int credit = Integer.parseInt(rs.getString(27));
                module = new Module(modID, moduleName, code, credit);

                studentProgressInfo.add(new StudentProgressInfo(id, StudentID, StudentModuleID, AssessmentTypeID, AssessmentDescription, Mark, Date, student, assessmentType, studentModule, module));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return studentProgressInfo;
    }

    public List<List<StudentProgressInfo>> selectStudentMarks(String studentID, HttpServletRequest request) {
        StudentModulesDAO studentModulesDAO = new StudentModulesDAO();
        List<StudentModules> studentModules = studentModulesDAO.selectStudentModulesByID(studentID, request);

        List<List<StudentProgressInfo>> studentProgressInfo = new ArrayList<>();

        for (int i = 0; i < studentModules.size(); i++) {
            List<StudentProgressInfo> spi = selectStudentMarksByStudentModuleID(studentModules.get(i).getID(), request);
            if (spi.size() > 0) {
                studentProgressInfo.add(spi);
            }
        }
        return studentProgressInfo;
    }

    public List<StudentProgressInfo> selectStudentFinalMarksByStudentModuleID(List<StudentModules> registeredModules, HttpServletRequest request) {
        List<StudentProgressInfo> studentProgressInfo = new ArrayList<>();
        User student = null;
        AssessmentType assessmentType = null;
        Module module = null;
        StudentModules studentModule = null;

        try (Connection connection = getConnection(request);
                Statement stmt = connection.createStatement();) {
            for (int i = 0; i < registeredModules.size(); i++) {
                ResultSet rs = stmt.executeQuery("SELECT * FROM studentprogressinfo "
                        + "inner join StudentModule "
                        + "on StudentModule.ID = studentprogressinfo.studentModuleID "
                        + "inner join User "
                        + "on User.Username = studentprogressinfo.StudentID "
                        + "inner join AssessmentType "
                        + "on AssessmentType.ID = studentprogressinfo.AssessmentTypeID "
                        + "inner join Module "
                        + "on Module.ID = StudentModule.ModuleID "
                        + "where YEAR(Date) = YEAR(NOW()) AND "
                        + " AssessmentTypeID = 1 AND StudentModuleID = " + registeredModules.get(i).getID());

                while (rs.next()) {

                    int id = rs.getInt(1);
                    String StudentID = rs.getString(7);
                    int StudentModuleID = Integer.parseInt(rs.getString(2));
                    int AssessmentTypeID = Integer.parseInt(rs.getString(3));
                    String AssessmentDescription = rs.getString(5);
                    int Mark = Integer.parseInt(rs.getString(4));
                    String Date = rs.getString(6);

                    //  String StudentID = rs.getString("StudentID");
                    int smID = rs.getInt(8);
                    int ModuleID = Integer.parseInt(rs.getString(9));
                    int Year = Integer.parseInt(rs.getString(10));
                    int Semester = Integer.parseInt(rs.getString(12));
                    int Passed = Integer.parseInt(rs.getString(13));
                    studentModule = new StudentModules(smID, StudentID, ModuleID, Year, Semester, Passed);

                    String username = rs.getString(14);
                    String name = rs.getString(15);
                    String surname = rs.getString(16);
                    String email = rs.getString(17);
                    String cellNo = rs.getString(18);
                    int roleID = Integer.parseInt(rs.getString(19));
                    boolean isDisabled = Boolean.parseBoolean(rs.getString(21));
                    student = new User(username, name, surname, email, cellNo, roleID, isDisabled);

                    int aID = rs.getInt(22);
                    String markDescription = rs.getString(23);
                    assessmentType = new AssessmentType(aID, markDescription);

                    int modID = rs.getInt(24);
                    String moduleName = rs.getString(25);
                    String code = rs.getString(26);
                    int credit = Integer.parseInt(rs.getString(27));
                    module = new Module(modID, moduleName, code, credit);
                    System.out.println("in here");
                    studentProgressInfo.add(new StudentProgressInfo(id, StudentID, StudentModuleID, AssessmentTypeID, AssessmentDescription, Mark, Date, student, assessmentType, studentModule, module));
                }
            }

        } catch (SQLException e) {
            printSQLException(e);
        }
        return studentProgressInfo;
    }

    public int getCreditsPassed(List<StudentProgressInfo> spiFinal, int newSemesterCalc, int pID, HttpServletRequest request) throws SQLException {
        StudentModulesDAO studentModulesDAO = new StudentModulesDAO();
        int credits = 0;

        for (int i = 0; i < spiFinal.size(); i++) {
            if (spiFinal.get(i).getMark() > 49) {
                credits += spiFinal.get(i).getModule().getCredit();
                spiFinal.get(i).getStudentModules().setPassed(1);
                studentModulesDAO.updateStudentModules(spiFinal.get(i).getStudentModules(), request);
            } else {
                spiFinal.get(i).getStudentModules().setPassed(2);
                studentModulesDAO.updateStudentModules(spiFinal.get(i).getStudentModules(), request);
                if (newSemesterCalc == 1) {//if semester one module failed, check if a prerequiste for semester 2
                    CurriculumDAO curriculumDAO = new CurriculumDAO();

                    int modID = spiFinal.get(i).getModule().getID();

                    List<StudentModules> semester2Modules = studentModulesDAO.selectStudentModulesThisYearSemesterTwo(spiFinal.get(i).getStudentID(), request);

                    for (int j = 0; j < semester2Modules.size(); j++) {
                        Curriculum c = curriculumDAO.selectModuleCurriculum(pID, semester2Modules.get(j).getModuleID(), request);

                        if (c.getPrerequisite() != null) {
                            boolean isPrerequisite = c.getPrerequisite().contains(spiFinal.get(i).getModule().getModuleCode());
                            if (isPrerequisite) {
                                studentModulesDAO.deleteModule(semester2Modules.get(j), request);
                            }
                        }
                    }

                }
            }
        }

        return credits;
    }

    public List<StudentProgressInfo> selectStudentModulesPassed(List<StudentModules> registeredModules, HttpServletRequest request) {
        List<StudentProgressInfo> studentProgressInfo = new ArrayList<>();
        User student = null;
        AssessmentType assessmentType = null;
        Module module = null;
        StudentModules studentModule = null;

        try (Connection connection = getConnection(request);
                Statement stmt = connection.createStatement();) {
            for (int i = 0; i < registeredModules.size(); i++) {
                ResultSet rs = stmt.executeQuery("SELECT * FROM studentprogressinfo "
                        + "inner join StudentModule "
                        + "on StudentModule.ID = studentprogressinfo.studentModuleID "
                        + "inner join User "
                        + "on User.Username = studentprogressinfo.StudentID "
                        + "inner join AssessmentType "
                        + "on AssessmentType.ID = studentprogressinfo.AssessmentTypeID "
                        + "inner join asm.Module "
                        + "on Module.ID = StudentModule.ModuleID "
                        + "where studentprogressinfo.Mark >49 AND"
                        + " AssessmentTypeID = 1 AND StudentModule.ID = " + registeredModules.get(i).getID());

                while (rs.next()) {
                    int id = rs.getInt(1);
                    String StudentID = rs.getString(7);
                    int StudentModuleID = Integer.parseInt(rs.getString(2));
                    int AssessmentTypeID = Integer.parseInt(rs.getString(3));
                    String AssessmentDescription = rs.getString(5);
                    int Mark = Integer.parseInt(rs.getString(4));
                    String Date = rs.getString(6);

                    //  String StudentID = rs.getString("StudentID");
                    int smID = rs.getInt(8);
                    int ModuleID = Integer.parseInt(rs.getString(9));
                    int Year = Integer.parseInt(rs.getString(10));
                    int Semester = Integer.parseInt(rs.getString(12));
                    studentModule = new StudentModules(smID, StudentID, ModuleID, Year, Semester);

                    String username = rs.getString(13);
                    String name = rs.getString(14);
                    String surname = rs.getString(15);
                    String email = rs.getString(16);
                    String cellNo = rs.getString(17);
                    int roleID = Integer.parseInt(rs.getString(18));
                    boolean isDisabled = Boolean.parseBoolean(rs.getString(20));
                    student = new User(username, name, surname, email, cellNo, roleID, isDisabled);

                    int aID = rs.getInt(21);
                    String markDescription = rs.getString(22);
                    assessmentType = new AssessmentType(aID, markDescription);

                    int modID = rs.getInt(23);
                    String moduleName = rs.getString(24);
                    String code = rs.getString(25);
                    int credit = Integer.parseInt(rs.getString(26));
                    module = new Module(modID, moduleName, code, credit);

                    studentProgressInfo.add(new StudentProgressInfo(id, StudentID, StudentModuleID, AssessmentTypeID, AssessmentDescription, Mark, Date, student, assessmentType, studentModule, module));
                }
            }

        } catch (SQLException e) {
            printSQLException(e);
        }
        return studentProgressInfo;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }

}
