/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataAccessLayer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import repo.MinCollegeRequirements;
import repo.Programme;
import repo.Student;
import repo.StudentModules;
import repo.StudentProgressInfo;
import repo.TermCondition;

/**
 *
 * @author Student
 */
public class TermConditionDAO {

    private static final String INSERT_SQL = "INSERT INTO TermCondition"
            + "  (StatusDescription, Colour, CreditPercentage)"
            + " VALUES (?, ?, ?);";
    private static final String SELECT_BY_ID = "select * from TermCondition where ID =?";
    private static final String SELECT_ALL = "select * from TermCondition";
    private static final String UPDATE_SQL = "update TermCondition set StatusDescription = ?,Colour= ?, CreditPercentage =? where ID = ?;";

    public TermConditionDAO() {
    }

    protected Connection getConnection(HttpServletRequest request) {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(request.getServletContext().getInitParameter("dbURL"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return connection;
    }

    public void insertTermCondition(TermCondition termCondition, HttpServletRequest request) throws SQLException {
        System.out.println(INSERT_SQL);
        try (Connection connection = getConnection(request); PreparedStatement preparedStatement = connection.prepareStatement(INSERT_SQL)) {
            preparedStatement.setString(1, termCondition.getStatusDescription());
            preparedStatement.setString(2, termCondition.getColour());
            preparedStatement.setInt(3, termCondition.getCreditPercentage());
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    public TermCondition selectTermCondition(int id, HttpServletRequest request) {
        TermCondition termCondition = null;
        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_BY_ID);) {
            preparedStatement.setInt(1, id);
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                String StatusDescription = rs.getString("StatusDescription");
                String Colour = rs.getString("Colour");
                int CreditPercentage = Integer.parseInt(rs.getString("CreditPercentage"));
                termCondition = new TermCondition(id, StatusDescription, Colour, CreditPercentage);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return termCondition;
    }

    public boolean updateTermCondition(TermCondition termCondition, HttpServletRequest request) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = getConnection(request); PreparedStatement statement = connection.prepareStatement(UPDATE_SQL);) {
            statement.setInt(4, termCondition.getID());
            statement.setString(1, termCondition.getStatusDescription());
            statement.setString(2, termCondition.getColour());
            statement.setInt(3, termCondition.getCreditPercentage());
            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    public List<TermCondition> selectAllTermCondition(HttpServletRequest request) {

        List<TermCondition> termConditions = new ArrayList<>();

        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL);) {
            System.out.println(preparedStatement);

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("ID");
                String StatusDescription = rs.getString("StatusDescription");
                String Colour = rs.getString("Colour");
                int CreditPercentage = Integer.parseInt(rs.getString("CreditPercentage"));
                termConditions.add(new TermCondition(id, StatusDescription, Colour, CreditPercentage));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return termConditions;
    }

    public void CalculateTermCondition(String studentID, HttpServletRequest request) throws SQLException {
        RegistrationDateDAO registrationDateDAO = new RegistrationDateDAO();

        if (!registrationDateDAO.checkRegistraionOpen(request)) { //Do calculation only if registration is closed
            StudentModulesDAO studentModulesDAO = new StudentModulesDAO();
            StudentDAO studentDAO = new StudentDAO();
            StudentProgressInfoDAO studentProgressInfoDAO = new StudentProgressInfoDAO();

            System.out.println("TERM CONDITION CALCULATIONS");
            System.out.println("-----------------------------------------------------");

            Student student = studentDAO.selectStudent(studentID, request);
            List<StudentModules> studentModulesSemester = new ArrayList<>();
            System.out.println("Last semester done : " + student.getLastSemesterCalc());
            int newSemesterCalc = 0;
            if (student.getLastSemesterCalc() == 2) { //If last calculation was done in semester 2, check semester 1
                studentModulesSemester = studentModulesDAO.selectStudentModulesThisYearSemesterOne(studentID, request);
                newSemesterCalc = 1;
                System.out.println("Do calculations for semester 1");
            } else {
                studentModulesSemester = studentModulesDAO.selectStudentModulesThisYearSemesterTwo(studentID, request);
                newSemesterCalc = 2;
                System.out.println("Do calculations for semester 2");
            }

            int noSemesterModules = studentModulesSemester.size();
            System.out.println("No of Modules registered: " + noSemesterModules);

            List<StudentProgressInfo> studentSemesterFinalMarks = studentProgressInfoDAO.selectStudentFinalMarksByStudentModuleID(studentModulesSemester, request);
            int noFinalMarks = studentSemesterFinalMarks.size();
            System.out.println("No of Modules with Final marks: " + noFinalMarks);

            if (noSemesterModules == noFinalMarks) {//Do calculation if all modules have final marks
                int newTerm = 0;

                ProgrammeDAO programmeDAO = new ProgrammeDAO();
                Programme studentProgramme = programmeDAO.selectProgramme(student.getProgrammeID(), request);
                double creditPerSemester = studentProgramme.getTotalCredits() / (studentProgramme.getNumberOfYears() * 2);

                int creditsObtained = studentProgressInfoDAO.getCreditsPassed(studentSemesterFinalMarks,newSemesterCalc,student.getProgrammeID(), request);

                System.out.println("Credits to pass for semester : " + creditPerSemester);
                System.out.println("Credits obtained this semester : " + creditsObtained);

                double percentPassed = (creditsObtained / creditPerSemester) * 100;
                System.out.println("Percentage of credits passed this semester : " + percentPassed);

                int updatedTotalCredits = creditsObtained + student.getTotalCredits();
                System.out.println("Updated total credits : " + updatedTotalCredits);
                double percentPassedTotal = (updatedTotalCredits / (studentProgramme.getTotalCredits() + 0.0)) * 100;
                System.out.println("Percentage of credits passed in total : " + percentPassedTotal);

                boolean isMoreThanOneSemester = studentModulesDAO.isNoOfSemesterMoreThanOne(studentID, request);
                System.out.println("Is More than one semester: " + isMoreThanOneSemester);

                MinCollegeReqDAO minCollegeReqDAO = new MinCollegeReqDAO();
                MinCollegeRequirements mcr = minCollegeReqDAO.selectMinCollegeReq(studentProgramme.getCollegeID(), request);

                int UpdatedSemestersCompleted = student.getTotalSemesters() + 1;
                System.out.println("Semesters completed : " + UpdatedSemestersCompleted);

                switch (student.getTermConditionID()) {
                    case 1: //GREEN
                        if (percentPassed >= 70) {
                            newTerm = 1;
                        } else if ((percentPassedTotal >= 75) || isMoreThanOneSemester) {
                            newTerm = 2;
                        } else if ((UpdatedSemestersCompleted <= mcr.getNoSemestersCompleted()) && (updatedTotalCredits >= (mcr.getMinCredits() * UpdatedSemestersCompleted))) {//above min collage progression requirements
                            newTerm = 2;
                        } else {
                            newTerm = 3;
                        }
                        break;
                    case 2: //ORANGE
                        if ((percentPassed >= 70) && (percentPassedTotal >= 75)) {
                            newTerm = 1;
                        } else if ((UpdatedSemestersCompleted <= mcr.getNoSemestersCompleted()) && (updatedTotalCredits >= (mcr.getMinCredits() * UpdatedSemestersCompleted))) {//above min faculity requittrments
                            newTerm = 2;
                        } else {
                            newTerm = 3;
                        }
                        break;
                    case 3: //RED
                        if ((UpdatedSemestersCompleted <= mcr.getNoSemestersCompleted()) && (updatedTotalCredits >= (mcr.getMinCredits() * UpdatedSemestersCompleted))) { //above min faculity requittrments
                            newTerm = 2;
                        } else {
                            newTerm = 3;
                        }
                        break;
                    default:
                        break;
                }

                if (newTerm > 0) {
                    //update student with new term, last semester calculation and updated total credits
                    student.setTermConditionID(newTerm);
                    student.setLastSemesterCalc(newSemesterCalc);
                    student.setTotalCredits(updatedTotalCredits);
                    student.setTotalSemesters(UpdatedSemestersCompleted);
                    studentDAO.updateStudentTerm(student, request);
                }

            }
        }

        System.out.println("TERM CONDITION CALCULATIONS ENDS");
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
