/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataAccessLayer;

import controllers.RegisterServlet;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import repo.RegistrationDate;

/**
 *
 * @author Student
 */
public class RegistrationDateDAO {

    private static final String SELECT_ALL = "select * from RegistrationDate";
    private static final String UPDATE_SQL = "update RegistrationDate set FromDate = ?, ToDate=? where ID = ?;";

    public RegistrationDateDAO() {
    }

    protected Connection getConnection(HttpServletRequest request) {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(request.getServletContext().getInitParameter("dbURL"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return connection;
    }

    public RegistrationDate selectRegistrationDate(HttpServletRequest request) {
        RegistrationDate registrationDate = null;
        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL);) {
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                String fromDate = rs.getString("FromDate");
                String toDate = rs.getString("ToDate");
                registrationDate = new RegistrationDate(fromDate, toDate);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return registrationDate;
    }

    public boolean updateRegistrationDate(RegistrationDate registrationDate, HttpServletRequest request) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = getConnection(request); PreparedStatement statement = connection.prepareStatement(UPDATE_SQL);) {

            statement.setInt(3, registrationDate.getID());
            statement.setString(1, registrationDate.getFromDate());
            statement.setString(2, registrationDate.getToDate());
            System.out.println(statement);
            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    public boolean checkRegistraionOpen(HttpServletRequest request) throws SQLException {
        RegistrationDate existingRegistrationDate = selectRegistrationDate(request);
        LocalDate Today = java.time.LocalDate.now();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.ENGLISH);
        LocalDate fromDate = LocalDate.parse(existingRegistrationDate.getFromDate(), formatter);
        LocalDate toDate = LocalDate.parse(existingRegistrationDate.getToDate(), formatter);

        boolean isOpen = false;

        if (Today.compareTo(fromDate) >= 0 && Today.compareTo(toDate) <= 0) {
            isOpen = true;

        } else {
            isOpen = false;

        }
        return isOpen;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }

}
