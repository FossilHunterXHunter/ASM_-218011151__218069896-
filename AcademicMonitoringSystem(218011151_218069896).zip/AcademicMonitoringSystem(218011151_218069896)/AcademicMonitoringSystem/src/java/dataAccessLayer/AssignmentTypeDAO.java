/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataAccessLayer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import repo.AssessmentType;

/**
 *
 * @author Student
 */
public class AssignmentTypeDAO {

    private static final String INSERT_ASSIGNMENTYPE_SQL = "INSERT INTO AssignmentType"
            + "  (MarkDescription"
            + " VALUES (?);";
    private static final String SELECT_ASSIGNMENTYPE_BY_ID = "select * from MarkDescription where ID =?";
    private static final String SELECT_ALL_ASSIGNMENTYPES = "select * from MarkDescription";
    private static final String UPDATE_ASSIGNMENTYPE_SQL = "update MarkDescription set MarkDescription = ? where ID = ?;";

    public AssignmentTypeDAO() {
    }

    protected Connection getConnection(HttpServletRequest request) {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(request.getServletContext().getInitParameter("dbURL"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return connection;
    }

    public void insertAssessmentType(AssessmentType assessmentType, HttpServletRequest request) throws SQLException {
        System.out.println(INSERT_ASSIGNMENTYPE_SQL);
        try (Connection connection = getConnection(request); PreparedStatement preparedStatement = connection.prepareStatement(INSERT_ASSIGNMENTYPE_SQL)) {
            preparedStatement.setString(1, assessmentType.getMarkDescription());
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    public AssessmentType selectAssessmentType(int id, HttpServletRequest request) {
        AssessmentType assessmentType = null;
        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ASSIGNMENTYPE_BY_ID);) {
            preparedStatement.setInt(1, id);
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                String MarkDescription = rs.getString("MarkDescription");
                assessmentType = new AssessmentType(id, MarkDescription);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return assessmentType;
    }

    public boolean updateAssessmentType(AssessmentType assessmentType, HttpServletRequest request) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = getConnection(request); PreparedStatement statement = connection.prepareStatement(UPDATE_ASSIGNMENTYPE_SQL);) {
            statement.setInt(2, assessmentType.getID());
            statement.setString(1, assessmentType.getMarkDescription());
            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    public List<AssessmentType> selectAllAssessmentTypes(HttpServletRequest request) {

        List<AssessmentType> assessmentTypes = new ArrayList<>();

        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_ASSIGNMENTYPES);) {
            System.out.println(preparedStatement);

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("ID");
                String MarkDescription = rs.getString("MarkDescription");
                assessmentTypes.add(new AssessmentType(id, MarkDescription));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return assessmentTypes;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
