/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataAccessLayer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import repo.Programme;

/**
 *
 * @author Student
 */
public class ProgrammeDAO {

    private static final String INSERT_PROGRAMME_SQL = "INSERT INTO Programme"
            + "  (ProgrammeName, TotalCredits, NumberOfYears, CollegeID)"
            + " VALUES (?, ?, ?, ? );";
    private static final String SELECT_PROGRAMME_BY_ID = "select * from Programme where ID =?";
    private static final String SELECT_PROGRAMME_BY_NAME = "select * from Programme where ProgrammeName =?";
    private static final String SELECT_ALL_PROGRAMMES = "select * from Programme";
    private static final String UPDATE_PROGRAMME_SQL = "update Programme set ProgrammeName = ?,TotalCredits= ?, NumberOfYears =?, CollegeID=? where ID = ?;";

    public ProgrammeDAO() {
    }

    protected Connection getConnection(HttpServletRequest request) {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(request.getServletContext().getInitParameter("dbURL"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return connection;
    }

    public void insertProgramme(Programme programme, HttpServletRequest request) throws SQLException {
        System.out.println(INSERT_PROGRAMME_SQL);
        try (Connection connection = getConnection(request); PreparedStatement preparedStatement = connection.prepareStatement(INSERT_PROGRAMME_SQL)) {
            preparedStatement.setString(1, programme.getProgrammeName());
            preparedStatement.setInt(2, programme.getTotalCredits());
            preparedStatement.setInt(3, programme.getNumberOfYears());
            preparedStatement.setInt(4, programme.getCollegeID());
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    public Programme selectProgramme(int id, HttpServletRequest request) {
        Programme programme = null;
        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_PROGRAMME_BY_ID);) {
            preparedStatement.setInt(1, id);
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                String programmeName = rs.getString("ProgrammeName");
                int totalCredits = Integer.parseInt(rs.getString("TotalCredits"));
                int numberOfYears = Integer.parseInt(rs.getString("NumberOfYears"));
                int collegeID = Integer.parseInt(rs.getString("CollegeID"));
                programme = new Programme(id, programmeName, totalCredits, numberOfYears, collegeID);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return programme;
    }

    public Programme selectProgrammeByName(String programmeName, HttpServletRequest request) {
        Programme programme = null;
        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_PROGRAMME_BY_NAME);) {
            preparedStatement.setString(1, programmeName);
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("ID");
                int totalCredits = Integer.parseInt(rs.getString("TotalCredits"));
                int numberOfYears = Integer.parseInt(rs.getString("NumberOfYears"));
                int collegeID = Integer.parseInt(rs.getString("CollegeID"));
                programme = new Programme(id, programmeName, totalCredits, numberOfYears, collegeID);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return programme;
    }

    public boolean updateProgramme(Programme programme, HttpServletRequest request) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = getConnection(request); PreparedStatement statement = connection.prepareStatement(UPDATE_PROGRAMME_SQL);) {
            statement.setInt(5, programme.getID());
            statement.setString(1, programme.getProgrammeName());
            statement.setInt(2, programme.getTotalCredits());
            statement.setInt(3, programme.getNumberOfYears());
            statement.setInt(4, programme.getCollegeID());
            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    public List<Programme> selectAllProgrammes(HttpServletRequest request) {

        List<Programme> programmes = new ArrayList<>();

        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_PROGRAMMES);) {
            System.out.println(preparedStatement);

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("ID");
                String programmeName = rs.getString("ProgrammeName");
                int totalCredits = Integer.parseInt(rs.getString("TotalCredits"));
                int numberOfYears = Integer.parseInt(rs.getString("NumberOfYears"));
                int collegeID = Integer.parseInt(rs.getString("CollegeID"));
                programmes.add(new Programme(id, programmeName, totalCredits, numberOfYears, collegeID));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return programmes;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }

}
