/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataAccessLayer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import repo.SemesterCredit;

/**
 *
 * @author Student
 */
public class SemesterCreditDAO {

    private static final String INSERT_SQL = "INSERT INTO SemesterCredit"
            + "  (ProgrammeID, Credit)"
            + " VALUES (?, ?);";
    private static final String SELECT_BY_ID = "select * from SemesterCredit where ID =?";
    private static final String SELECT_ALL = "select * from SemesterCredit";
    private static final String UPDATE_SQL = "update SemesterCredit set ProgrammeID = ?,Credit= ? where ID = ?;";

    public SemesterCreditDAO() {
    }

    protected Connection getConnection(HttpServletRequest request) {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(request.getServletContext().getInitParameter("dbURL"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return connection;
    }

    public void insertSemesterCredit(SemesterCredit semesterCredit, HttpServletRequest request) throws SQLException {
        System.out.println(INSERT_SQL);
        try (Connection connection = getConnection(request); PreparedStatement preparedStatement = connection.prepareStatement(INSERT_SQL)) {
            preparedStatement.setInt(1, semesterCredit.getProgrammeID());
            preparedStatement.setInt(2, semesterCredit.getCredit());
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    public SemesterCredit selectSemesterCredit(int id, HttpServletRequest request) {
        SemesterCredit semesterCredit = null;
        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_BY_ID);) {
            preparedStatement.setInt(1, id);
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int ProgrammeID = Integer.parseInt(rs.getString("ProgrammeID"));
                int Credit = Integer.parseInt(rs.getString("Credit"));
                semesterCredit = new SemesterCredit(id, ProgrammeID, Credit);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return semesterCredit;
    }

    public boolean updateSemesterCredit(SemesterCredit semesterCredit, HttpServletRequest request) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = getConnection(request); PreparedStatement statement = connection.prepareStatement(UPDATE_SQL);) {
            statement.setInt(3, semesterCredit.getID());
            statement.setInt(1, semesterCredit.getProgrammeID());
            statement.setInt(2, semesterCredit.getCredit());
            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    public List<SemesterCredit> selectAllSemesterCredit(HttpServletRequest request) {

        List<SemesterCredit> semesterCredits = new ArrayList<>();

        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL);) {
            System.out.println(preparedStatement);

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("ID");
                int ProgrammeID = Integer.parseInt(rs.getString("ProgrammeID"));
                int Credit = Integer.parseInt(rs.getString("Credit"));

                semesterCredits.add(new SemesterCredit(id, ProgrammeID, Credit));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return semesterCredits;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }

}
