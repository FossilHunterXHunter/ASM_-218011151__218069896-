package dataAccessLayer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import repo.Student;

public class StudentDAO {

    private static final String INSERT_STUDENT_SQL = "INSERT INTO Student"
            + "  (ID, ProgrammeID, TermConditionID, LastSemesterCalc, TotalCredits, TotalSemesters)"
            + " VALUES (?, ?, ?, 2, 0, 0);";
    private static final String SELECT_STUDENT_BY_ID = "select * from Student where ID =?";
    private static final String SELECT_ALL_STUDENTS = "select * from Student";
    private static final String UPDATE_STUDENT_SQL = "update Student set ProgrammeID = ?,TermConditionID= ? where ID = ?;";
    private static final String UPDATE_STUDENT_TERM_SQL = "update Student set TermConditionID = ?, LastSemesterCalc=?,TotalCredits= ?, TotalSemesters=? where ID = ?;";

    public StudentDAO() {
    }

    protected Connection getConnection(HttpServletRequest request) {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(request.getServletContext().getInitParameter("dbURL"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return connection;
    }

    public void insertStudent(Student student, HttpServletRequest request) throws SQLException {
        System.out.println(INSERT_STUDENT_SQL);
        try (Connection connection = getConnection(request); PreparedStatement preparedStatement = connection.prepareStatement(INSERT_STUDENT_SQL)) {
            preparedStatement.setString(1, student.getStudentID());
            preparedStatement.setInt(2, student.getProgrammeID());
            preparedStatement.setInt(3, student.getTermConditionID());
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    public Student selectStudent(String id, HttpServletRequest request) {
        Student student = null;
        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_STUDENT_BY_ID);) {
            preparedStatement.setString(1, id);
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int programmeID = Integer.parseInt(rs.getString(2));
                int termConditionID = Integer.parseInt(rs.getString(3));
                int lastSemesterCalc = Integer.parseInt(rs.getString(4));
                int totalCredits = Integer.parseInt(rs.getString(5));
                int totalSemesters = Integer.parseInt(rs.getString(6));
                student = new Student(id, programmeID, termConditionID, lastSemesterCalc, totalCredits, totalSemesters);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return student;
    }

    public boolean updateStudent(Student student, HttpServletRequest request) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = getConnection(request); PreparedStatement statement = connection.prepareStatement(UPDATE_STUDENT_SQL);) {
            statement.setString(3, student.getStudentID());
            statement.setInt(1, student.getProgrammeID());
            statement.setInt(2, student.getTermConditionID());
            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    public boolean updateStudentTerm(Student student, HttpServletRequest request) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = getConnection(request); PreparedStatement statement = connection.prepareStatement(UPDATE_STUDENT_TERM_SQL);) {
            statement.setString(5, student.getStudentID());
            statement.setInt(1, student.getTermConditionID());
            statement.setInt(2, student.getLastSemesterCalc());
            statement.setInt(3, student.getTotalCredits());
            statement.setInt(4, student.getTotalSemesters());
            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    public List<Student> selectAllStudents(HttpServletRequest request) {

        List<Student> students = new ArrayList<>();

        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_STUDENTS);) {
            System.out.println(preparedStatement);

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                String studentID = rs.getString("ID");
                int programmeID = Integer.parseInt(rs.getString("PogrammeID"));
                int termConditionID = Integer.parseInt(rs.getString("TermConditionID"));
                int lastSemesterCalc = Integer.parseInt(rs.getString(4));
                int totalCredits = Integer.parseInt(rs.getString(5));
                int totalSemesters = Integer.parseInt(rs.getString(6));
                students.add(new Student(studentID, programmeID, termConditionID, lastSemesterCalc, totalCredits, totalSemesters));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return students;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
