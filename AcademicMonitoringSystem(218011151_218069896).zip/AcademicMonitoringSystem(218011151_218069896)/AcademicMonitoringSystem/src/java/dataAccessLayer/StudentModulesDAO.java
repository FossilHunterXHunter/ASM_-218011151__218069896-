/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataAccessLayer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import repo.Curriculum;
import repo.Module;
import repo.Student;
import repo.StudentModules;

/**
 *
 * @author Student
 */
public class StudentModulesDAO {

    private static final String INSERT_SQL = "INSERT INTO StudentModule"
            + "  (StudentID, ModuleID, Year, Semester, Passed)"
            + " VALUES (?, ?, YEAR(NOW()), ?, 0);";
    private static final String SELECT_BY_ID = "select * from StudentModule where ID =?";
    private static final String SELECT_ALL = "select * from StudentModule";
    private static final String UPDATE_SQL = "update StudentModule set StudentID = ?,ModuleID= ?, Year =?, Semester=?, Passed=? where ID = ?;";
    private static final String SELECT_ID_SQL = "SELECT ID FROM studentmodule "
            + "where Year = Year(NOW()) and StudentID = ?"
            + "and ModuleID = ? and Semester = ?";

    public StudentModulesDAO() {
    }

    protected Connection getConnection(HttpServletRequest request) {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(request.getServletContext().getInitParameter("dbURL"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return connection;
    }

    public void insertStudentModules(StudentModules studentModules, HttpServletRequest request) throws SQLException {
        System.out.println(INSERT_SQL);
        try (Connection connection = getConnection(request); PreparedStatement preparedStatement = connection.prepareStatement(INSERT_SQL)) {
            preparedStatement.setString(1, studentModules.getStudentID());
            preparedStatement.setInt(2, studentModules.getModuleID());
            preparedStatement.setInt(3, studentModules.getSemester());
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    public StudentModules selectStudentModules(int id, HttpServletRequest request) {
        StudentModules studentModules = null;
        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_BY_ID);) {
            preparedStatement.setInt(1, id);
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                String StudentID = rs.getString("StudentID");
                int ModuleID = Integer.parseInt(rs.getString("ModuleID"));
                int Year = Integer.parseInt(rs.getString("Year"));
                int Semester = Integer.parseInt(rs.getString("Semester"));
                int Passed = Integer.parseInt(rs.getString("Passed"));
                studentModules = new StudentModules(id, StudentID, ModuleID, Year, Semester, Passed);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return studentModules;
    }

    public boolean updateStudentModules(StudentModules studentModules, HttpServletRequest request) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = getConnection(request); PreparedStatement statement = connection.prepareStatement(UPDATE_SQL);) {
            statement.setInt(6, studentModules.getID());
            statement.setString(1, studentModules.getStudentID());
            statement.setInt(2, studentModules.getModuleID());
            statement.setInt(3, studentModules.getYear());
            statement.setInt(4, studentModules.getSemester());
            statement.setInt(5, studentModules.getPassed());
            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    public void insertStudentModules(Student student, List<Curriculum> curriculum, HttpServletRequest request) throws SQLException {
        System.out.println(INSERT_SQL);
        for (int i = 0; i < curriculum.size(); i++) {
            try (Connection connection = getConnection(request); PreparedStatement preparedStatement = connection.prepareStatement(INSERT_SQL)) {
                preparedStatement.setString(1, student.getStudentID());
                preparedStatement.setInt(2, curriculum.get(i).getModuleID());
                preparedStatement.setInt(3, curriculum.get(i).getSemester());
                System.out.println(preparedStatement);
                preparedStatement.executeUpdate();
            } catch (SQLException e) {
                printSQLException(e);
            }
        }
    }

    public List<StudentModules> selectAllStudentModules(HttpServletRequest request) {

        List<StudentModules> studentModules = new ArrayList<>();

        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL);) {
            System.out.println(preparedStatement);

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("ID");
                String StudentID = rs.getString("StudentID");
                int ModuleID = Integer.parseInt(rs.getString("ModuleID"));
                int Year = Integer.parseInt(rs.getString("Year"));
                int Semester = Integer.parseInt(rs.getString("Semester"));
                int Passed = Integer.parseInt(rs.getString("Passed"));
                studentModules.add(new StudentModules(id, StudentID, ModuleID, Year, Semester, Passed));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return studentModules;
    }

    public List<StudentModules> selectRequisitesPassed(Student student, String req, HttpServletRequest request) {

        List<StudentModules> studentModules = new ArrayList<>();

        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM studentmodule "
                        + "WHERE StudentID = '" + student.getStudentID() + "' AND "
                        + "Passed = 1 AND "
                        + "ModuleID IN (SELECT ID FROM asm.module where ModuleCode IN (" + req + "))");) {
            System.out.println(preparedStatement);

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("ID");
                String StudentID = rs.getString("StudentID");
                int ModuleID = Integer.parseInt(rs.getString("ModuleID"));
                int Year = Integer.parseInt(rs.getString("Year"));
                int Semester = Integer.parseInt(rs.getString("Semester"));
                int Passed = Integer.parseInt(rs.getString("Passed"));
                studentModules.add(new StudentModules(id, StudentID, ModuleID, Year, Semester, Passed));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return studentModules;
    }

    public int selectStudentModuleID(StudentModules sm, HttpServletRequest request) {

        int smID = 0;

        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ID_SQL);) {
            preparedStatement.setString(1, sm.getStudentID());
            preparedStatement.setInt(2, sm.getModuleID());
            preparedStatement.setInt(3, sm.getSemester());
            System.out.println(preparedStatement);

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                smID = rs.getInt("ID");
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return smID;
    }

    public boolean deleteModule(StudentModules sm, HttpServletRequest request) {

        boolean rowUpdated=false;

         try (Connection connection = getConnection(request);
                 PreparedStatement statement = connection.prepareStatement("DELETE FROM StudentModule where ID="+sm.getID());) {

            rowUpdated = statement.executeUpdate() > 0;
        } catch (SQLException e) {
            printSQLException(e);
        }
       return rowUpdated;
    }

    public List<StudentModules> selectStudentModulesByID(String studentID, HttpServletRequest request) {

        List<StudentModules> studentModules = new ArrayList<>();

        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM StudentModule "
                        + "where studentID ='" + studentID + "'");) {
            System.out.println(preparedStatement);

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("ID");
                String StudentID = rs.getString("StudentID");
                int ModuleID = Integer.parseInt(rs.getString("ModuleID"));
                int Year = Integer.parseInt(rs.getString("Year"));
                int Semester = Integer.parseInt(rs.getString("Semester"));
                int Passed = Integer.parseInt(rs.getString("Passed"));
                studentModules.add(new StudentModules(id, StudentID, ModuleID, Year, Semester, Passed));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return studentModules;
    }
    
    public List<StudentModules> selectStudentModulesByStudentID(String studentID, HttpServletRequest request) {

        List<StudentModules> studentModules = new ArrayList<>();

        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM StudentModule "
                        + "inner join Module "
                        + "on module.ID=StudentModule.ModuleID "
                        + "where studentID ='" + studentID + "'");) {
            System.out.println(preparedStatement);

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int id = rs.getInt(1);
                String StudentID = rs.getString("StudentID");
                int ModuleID = Integer.parseInt(rs.getString("ModuleID"));
                int Year = Integer.parseInt(rs.getString("Year"));
                int Semester = Integer.parseInt(rs.getString("Semester"));
                int Passed = Integer.parseInt(rs.getString("Passed"));
                
                String ModuleName = rs.getString(8);
                String ModuleCode = rs.getString(9);
                int Credit = Integer.parseInt(rs.getString(10));
                Module Module = new Module(ModuleID, ModuleName, ModuleCode, Credit);
                
                studentModules.add(new StudentModules(id, StudentID, ModuleID, Year, Semester, Passed, Module));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return studentModules;
    }

    public List<StudentModules> selectStudentModulesRegisiteredThisYear(String studentID, HttpServletRequest request) {

        List<StudentModules> studentModules = new ArrayList<>();

        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM StudentModule "
                        + "WHERE year = YEAR(NOW()) AND studentID ='" + studentID + "'");) {
            System.out.println(preparedStatement);

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("ID");
                String StudentID = rs.getString("StudentID");
                int ModuleID = Integer.parseInt(rs.getString("ModuleID"));
                int Year = Integer.parseInt(rs.getString("Year"));
                int Semester = Integer.parseInt(rs.getString("Semester"));
                int Passed = Integer.parseInt(rs.getString("Passed"));
                studentModules.add(new StudentModules(id, StudentID, ModuleID, Year, Semester, Passed));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return studentModules;
    }

    public List<StudentModules> selectStudentModulesThisYearSemesterOne(String studentID, HttpServletRequest request) {

        List<StudentModules> studentModules = new ArrayList<>();

        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM StudentModule "
                        + "WHERE year = YEAR(NOW()) AND Semester = 1 AND studentID ='" + studentID + "'");) {
            System.out.println(preparedStatement);

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("ID");
                String StudentID = rs.getString("StudentID");
                int ModuleID = Integer.parseInt(rs.getString("ModuleID"));
                int Year = Integer.parseInt(rs.getString("Year"));
                int Semester = Integer.parseInt(rs.getString("Semester"));
                int Passed = Integer.parseInt(rs.getString("Passed"));
                studentModules.add(new StudentModules(id, StudentID, ModuleID, Year, Semester, Passed));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return studentModules;
    }

    public List<StudentModules> selectStudentModulesThisYearSemesterTwo(String studentID, HttpServletRequest request) {

        List<StudentModules> studentModules = new ArrayList<>();

        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM StudentModule "
                        + "WHERE year = YEAR(NOW()) AND Semester = 2 AND studentID ='" + studentID + "'");) {
            System.out.println(preparedStatement);

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("ID");
                String StudentID = rs.getString("StudentID");
                int ModuleID = Integer.parseInt(rs.getString("ModuleID"));
                int Year = Integer.parseInt(rs.getString("Year"));
                int Semester = Integer.parseInt(rs.getString("Semester"));
                int Passed = Integer.parseInt(rs.getString("Passed"));
                studentModules.add(new StudentModules(id, StudentID, ModuleID, Year, Semester, Passed));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return studentModules;
    }

    public boolean isNoOfSemesterMoreThanOne(String studentID, HttpServletRequest request) {

        boolean isMoreThanOne = false;
        int count = 0;

        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement("SELECT Semester, Count(*) FROM StudentModule "
                        + "where Year = Year(NOW()) and studentID ='" + studentID + "' Group by Semester");) {
            System.out.println(preparedStatement);

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int semesterCount = rs.getInt(1);
                if (semesterCount > 0) {
                    count++;
                }
            }

            if (count == 2) {
                isMoreThanOne = true;
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return isMoreThanOne;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }

}
