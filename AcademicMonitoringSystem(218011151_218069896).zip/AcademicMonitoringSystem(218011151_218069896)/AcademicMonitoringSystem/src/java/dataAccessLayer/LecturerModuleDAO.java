/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataAccessLayer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import repo.LecturerModule;
import repo.Module;
import repo.User;

/**
 *
 * @author Student
 */
public class LecturerModuleDAO {

    private static final String INSERT_SQL = "INSERT INTO Lecturermodule"
            + "  (LecturerID, ModuleID, Year, Semester, Date)"
            + " VALUES (?, ?, ?, ?, NOW());";
    private static final String SELECT_BY_ID = "select * from Lecturermodule where ID =?";
    private static final String SELECT_ALL = "select * from Lecturermodule";
    private static final String UPDATE_SQL = "update Lecturermodule set LecturerID = ?,ModuleID= ?, Year =?. Semester=? where ID = ?;";
    private static final String SELECT_USER_LECTURERS = "select * from user where Role =2";
    private static final String SELECT_LECTURERS_BY_NAME = "select * from user where Role =2 and Name like '%?%'";
    private static final String SELECT_MODULE_BY_NAME = "select * from module where ModuleName like '%?%'";
    private static final String SELECT_LECTURER_MODULES = "select * from Lecturermodule inner join module"
            + "on module.ID = lecturermodule.moduleID where lecturerID = ?";

    public LecturerModuleDAO() {
    }

    protected Connection getConnection(HttpServletRequest request) {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(request.getServletContext().getInitParameter("dbURL"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return connection;
    }

    public void insertLecturerModule(LecturerModule lecturerModule, HttpServletRequest request) throws SQLException {
        System.out.println(INSERT_SQL);
        try (Connection connection = getConnection(request); PreparedStatement preparedStatement = connection.prepareStatement(INSERT_SQL)) {
            preparedStatement.setString(1, lecturerModule.getLecturerID());
            preparedStatement.setInt(2, lecturerModule.getModuleID());
            preparedStatement.setInt(3, lecturerModule.getYear());
            preparedStatement.setInt(4, lecturerModule.getSemester());
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    public User selectUser(String name, HttpServletRequest request) {
        User user = null;
        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_USER_LECTURERS);) {
            preparedStatement.setString(1, name);
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                String surname = rs.getString("surname");
                boolean isDisabled = Boolean.parseBoolean(rs.getString("isDisabled"));
                user.setSurname(surname);
                user.setName(name);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return user;
    }

    public LecturerModule selectLecturerModule(int id, HttpServletRequest request) {
        LecturerModule lecturerModule = null;
        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_BY_ID);) {
            preparedStatement.setInt(1, id);
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                String LecturerID = rs.getString("LecturerID");
                int ModuleID = Integer.parseInt(rs.getString("ModuleID"));
                int Year = Integer.parseInt(rs.getString("Year"));
                int Semester = Integer.parseInt(rs.getString("Semester"));
                lecturerModule = new LecturerModule(id, LecturerID, ModuleID, Year, Semester);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return lecturerModule;
    }

    public boolean updateLecturerModule(LecturerModule lecturerModule, HttpServletRequest request) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = getConnection(request); PreparedStatement statement = connection.prepareStatement(UPDATE_SQL);) {
            statement.setInt(4, lecturerModule.getID());
            statement.setString(1, lecturerModule.getLecturerID());
            statement.setInt(2, lecturerModule.getModuleID());
            statement.setInt(3, lecturerModule.getYear());
            statement.setInt(4, lecturerModule.getSemester());
            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    public List<LecturerModule> selectAllLecturerModule(HttpServletRequest request) {

        List<LecturerModule> lecturerModules = new ArrayList<>();

        try (Connection connection = getConnection(request);
                PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL);) {
            System.out.println(preparedStatement);

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("ID");
                String LecturerID = rs.getString("LecturerID");
                int ModuleID = Integer.parseInt(rs.getString("ModuleID"));
                int Year = Integer.parseInt(rs.getString("Year"));
                int Semester = Integer.parseInt(rs.getString("Semester"));
                lecturerModules.add(new LecturerModule(id, LecturerID, ModuleID, Year, Semester));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return lecturerModules;
    }

    public List<LecturerModule> selectLecturerModuleByUserID(String lid, HttpServletRequest request) {

        List<LecturerModule> lecturerModules = new ArrayList<>();
        Module module = null;

        try (Connection connection = getConnection(request);
                Statement stmt = connection.createStatement();) {

            ResultSet rs = stmt.executeQuery("select * from Lecturermodule "
                    + "inner join module "
                    + "ON module.ID = lecturermodule.moduleID "
                    + "where lecturermodule.year = Year(Now()) and lecturerID=" + lid);

            while (rs.next()) {
                int id = rs.getInt("id");
                String LecturerID = rs.getString("LecturerID");
                int ModuleID = Integer.parseInt(rs.getString("ModuleID"));
                int Year = Integer.parseInt(rs.getString("Year"));
                int Semester = Integer.parseInt(rs.getString("Semester"));

                String moduleName = rs.getString("ModuleName");
                String moduleCode = rs.getString("ModuleCode");
                int credit = Integer.parseInt(rs.getString("Credit"));
                module = new Module(ModuleID, moduleName, moduleCode, credit);

                lecturerModules.add(new LecturerModule(id, LecturerID, ModuleID, Year, Semester, module));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return lecturerModules;
    }

    public List<User> selectEnrolledStudents(int mid, HttpServletRequest request) {

        List<User> students = new ArrayList<>();

        try (Connection connection = getConnection(request);
                Statement stmt = connection.createStatement();) {

            ResultSet rs = stmt.executeQuery("SELECT * FROM asm.studentmodule "
                    + "inner join asm.user "
                    + "on user.Username = studentmodule.StudentID "
                    + "where studentmodule.year = Year(Now()) and ModuleID =" + mid);

            while (rs.next()) {
                String username = rs.getString("username");
                String name = rs.getString("name");
                String surname = rs.getString("surname");
                String email = rs.getString("email");
                String cellNo = rs.getString("PhoneNumber");
                int roleID = Integer.parseInt(rs.getString("roleID"));
                boolean isDisabled = Boolean.parseBoolean(rs.getString("isDisabled"));
                students.add(new User(username, name, surname, email, cellNo, roleID, isDisabled));

            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return students;
    }

    public List<User> selectLecturerByName(String name, HttpServletRequest request) {
        List<User> users = new ArrayList<>();
        try (Connection connection = getConnection(request);
            PreparedStatement preparedStatement = connection.prepareStatement("select * from user where RoleID =2 and Name like '%" + name + "%'");) {
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                String lName = rs.getString("name");
                String username = rs.getString("username");
                String surname = rs.getString("surname");
                String email = rs.getString("email");
                String cellNo = rs.getString("PhoneNumber");
                int roleID = Integer.parseInt(rs.getString("roleID"));
                boolean isDisabled = Boolean.parseBoolean(rs.getString("isDisabled"));

                users.add(new User(username, lName, surname, email, cellNo, roleID, isDisabled));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return users;
    }

    public List<Module> selectModuleByName(String name, HttpServletRequest request) {
        List<Module> modules = new ArrayList<>();
        try (Connection connection = getConnection(request);
            PreparedStatement preparedStatement = connection.prepareStatement("select * from module where ModuleName like '%" + name + "%'");) {
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("ID");
                String moduleName = rs.getString("ModuleName");
                String moduleCode = rs.getString("ModuleCode");
                int credit = Integer.parseInt(rs.getString("Credit"));
                modules.add(new Module(id, moduleName, moduleCode, credit));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return modules;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }

}
