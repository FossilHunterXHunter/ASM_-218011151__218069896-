/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repo;

/**
 *
 * @author Student
 */
public class Curriculum {

    private int ID;
    private int ModuleID;
    private int Semester;
    private int Year;
    private int ProgrammeID;
    private String ModuleType;
    private String Prerequisite;
    private String Corequisite;

    private Module module;

    public Curriculum() {

    }

    public Curriculum(int i, int p, int y, int s, int mid, String mt, String pre, String co, Module mod) {
        ID = i;
        ModuleID = mid;
        Year = y;
        Semester = s;
        ProgrammeID = p;
        ModuleType = mt;
        Prerequisite = pre;
        Corequisite = co;
        module = mod;
    }

    public Curriculum(int i, int p, int y, int s, int mid, String mt, String pre, String co) {
        ID = i;
        ModuleID = mid;
        Year = y;
        Semester = s;
        ProgrammeID = p;
        ModuleType = mt;
        Prerequisite = pre;
        Corequisite = co;
    }

    public Curriculum(int p, int y, int s, int mid, String mt, String pre, String co) {
        ModuleID = mid;
        Semester = s;
        Year = y;
        ProgrammeID = p;
        ModuleType = mt;
        Prerequisite = pre;
        Corequisite = co;
    }

    public Curriculum(int i, int p, int y, int s, int mid, String mt) {
        ID = i;
        ModuleID = mid;
        Year = y;
        Semester = s;
        ProgrammeID = p;
        ModuleType = mt;
    }

    public Curriculum(int p, int y, int s, int mid, String mt) {
        ModuleID = mid;
        Year = y;
        Semester = s;
        ProgrammeID = p;
        ModuleType = mt;
    }

    public int getID() {
        return ID;
    }

    public void setID(int i) {
        ID = i;
    }

    public int getModuleID() {
        return ModuleID;
    }

    public void setModuleID(int m) {
        ModuleID = m;
    }

    public int getYear() {
        return Year;
    }

    public void setYear(int y) {
        Year = y;
    }

    public int getSemester() {
        return Semester;
    }

    public void setSemester(int s) {
        Semester = s;
    }

    public int getProgrammeID() {
        return ProgrammeID;
    }

    public void setProgrammeID(int p) {
        ProgrammeID = p;
    }

    public String getModuleType() {
        return ModuleType;
    }

    public void setModuleType(String mt) {
        ModuleType = mt;
    }

    public String getPrerequisite() {
        return Prerequisite;
    }

    public void setPrerequisite(String p) {
        Prerequisite = p;
    }

    public String getCorequisite() {
        return Corequisite;
    }

    public void setCorequisite(String c) {
        Corequisite = c;
    }

    public void setModule(Module m) {
        module = m;
    }

    public Module getModule() {
        return module;
    }

}
