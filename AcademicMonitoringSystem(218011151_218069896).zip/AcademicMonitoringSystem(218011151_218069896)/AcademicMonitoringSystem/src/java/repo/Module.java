/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repo;

/**
 *
 * @author Student
 */
public class Module {

    private int ID;
    private String ModuleName;
    private String ModuleCode;
    private int Credit;

    public Module() {

    }

    public Module(int i, String mn, String mc, int c) {
        ID = i;
        ModuleName = mn;
        ModuleCode = mc;
        Credit = c;
    }

        public Module(String mn, String mc, int c) {
        ModuleName = mn;
        ModuleCode = mc;
        Credit = c;
    }
    
    public int getID() {
        return ID;
    }

    public void setID(int i) {
        ID = i;
    }

    public String getModuleName() {
        return ModuleName;
    }

    public void setModuleName(String m) {
        ModuleName = m;
    }

    public String getModuleCode() {
        return ModuleCode;
    }

    public void setModuleCode(String m) {
        ModuleCode = m;
    }

    public int getCredit() {
        return Credit;
    }

    public void setCredit(int c) {
        Credit = c;
    }

}
