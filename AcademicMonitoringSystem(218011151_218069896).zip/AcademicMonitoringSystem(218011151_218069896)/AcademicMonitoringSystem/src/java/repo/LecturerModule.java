/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repo;

/**
 *
 * @author Student
 */
public class LecturerModule {

    private int ID;
    private String LecturerID;
    private int ModuleID;
    private int Year;
    private int Semester;

    private Module ModuleDetails;

    public LecturerModule() {
    }

    public LecturerModule(int i, String lid, int mid, int y, int s) {
        ID = i;
        LecturerID = lid;
        ModuleID = mid;
        Year = y;
        Semester = s;
    }

    public LecturerModule(int i, String lid, int mid, int y, int s, Module m) {
        ID = i;
        LecturerID = lid;
        ModuleID = mid;
        Year = y;
        Semester = s;
        ModuleDetails = m;
    }

    public LecturerModule(String lid, int mid, int y, int s) {
        LecturerID = lid;
        ModuleID = mid;
        Year = y;
        Semester = s;
    }

    public int getID() {
        return ID;
    }

    public void setID(int i) {
        ID = i;
    }

    public String getLecturerID() {
        return LecturerID;
    }

    public void setLecturerID(String l) {
        LecturerID = l;
    }

    public int getModuleID() {
        return ModuleID;
    }

    public void setModuleID(int m) {
        ModuleID = m;
    }

    public int getYear() {
        return Year;
    }

    public void setYear(int y) {
        Year = y;
    }

    public int getSemester() {
        return Semester;
    }

    public void setSemester(int s) {
        Semester = s;
    }

    public void setModule(Module m) {
        ModuleDetails = m;
    }

    public Module getModule() {
        return ModuleDetails;
    }

}
