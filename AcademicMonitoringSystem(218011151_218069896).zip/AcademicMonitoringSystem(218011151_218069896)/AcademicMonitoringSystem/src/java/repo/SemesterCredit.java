/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repo;

/**
 *
 * @author Student
 */
public class SemesterCredit {

    private int ID;
    private int ProgrammeID;
    private int Credit;

    public SemesterCredit() {

    }

    public SemesterCredit(int i, int p, int c) {
        ID = i;
        ProgrammeID = p;
        Credit = c;
    }

    public SemesterCredit(int p, int c) {
        ProgrammeID = p;
        Credit = c;
    }

    public int getID() {
        return ID;
    }

    public void setID(int i) {
        ID = i;
    }

    public int getProgrammeID() {
        return ProgrammeID;
    }

    public void setProgrammeID(int p) {
        ProgrammeID = p;
    }

    public int getCredit() {
        return ID;
    }

    public void setCredit(int c) {
        Credit = c;
    }

}
