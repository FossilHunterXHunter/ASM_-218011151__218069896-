/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repo;

/**
 *
 * @author Student
 */
public class User {

    private String Username;
    private String Name;
    private String Surname;
    private String Email;
    private String CellNo;
    private int RoleID;
    private boolean isDisabled;
    private String Password;

    public User() {
    }

    public User(String u, String n, String s, String e, String c, int r, boolean i, String p) {
        Username = u;
        Name = n;
        Surname = s;
        Email = e;
        CellNo = c;
        RoleID = r;
        isDisabled = i;
        Password = p;
    }

    public User(String u, String n, String s, String e, String c, int r, boolean i) {
        Username = u;
        Name = n;
        Surname = s;
        Email = e;
        CellNo = c;
        RoleID = r;
        isDisabled = i;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String u) {
        Username = u;
    }

    public String getName() {
        return Name;
    }

    public void setName(String n) {
        Name = n;
    }

    public String getSurname() {
        return Surname;
    }

    public void setSurname(String s) {
        Surname = s;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String e) {
        Email = e;
    }

    public String getCellNo() {
        return CellNo;
    }

    public void setCellNo(String c) {
        CellNo = c;
    }

    public int getRoleID() {
        return RoleID;
    }

    public void setRoleID(int r) {
        RoleID = r;
    }

    public boolean getIsDisabled() {
        return isDisabled;
    }

    public void setIsDisabled(boolean i) {
        isDisabled = i;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String p) {
        Password = p;
    }

}
