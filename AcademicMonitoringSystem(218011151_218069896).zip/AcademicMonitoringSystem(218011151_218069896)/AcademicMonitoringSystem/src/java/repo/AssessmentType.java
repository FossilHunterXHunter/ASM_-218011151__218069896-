/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repo;

/**
 *
 * @author Student
 */
public class AssessmentType {

    private int ID;
    private String MarkDescription;

    public AssessmentType() {

    }

    public AssessmentType(int i, String m) {
        ID = i;
        MarkDescription = m;
    }

    public AssessmentType(String m) {
        MarkDescription = m;
    }

    public int getID() {
        return ID;
    }

    public void setID(int i) {
        ID = i;
    }

    public String getMarkDescription() {
        return MarkDescription;
    }

    public void setMarkDescription(String m) {
        MarkDescription = m;
    }

}
