/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repo;

/**
 *
 * @author Student
 */
public class MinCollegeRequirements {

    private int ID;
    private int MinCredits;
    private int NoSemestersCompleted;
    private String College;
    private int NoYearQualification;

    public MinCollegeRequirements(int i, int m, int n, String c, int ny) {
        ID = i;
        MinCredits = m;
        NoSemestersCompleted = n;
        College = c;
        NoYearQualification = ny;
    }

    public void setID(int i) {
        ID = i;
    }

    public int getID() {
        return ID;
    }

    public void setMinCredits(int m) {
        MinCredits = m;
    }

    public int getMinCredits() {
        return MinCredits;
    }

    public void setNoSemestersCompleted(int n) {
        NoSemestersCompleted = n;
    }

    public int getNoSemestersCompleted() {
        return NoSemestersCompleted;
    }

    public void setCollege(String c) {
        College = c;
    }

    public String getCollege() {
        return College;
    }

    public void setNoYearQualification(int n) {
        NoYearQualification = n;
    }

    public int getNoYearQualification() {
        return NoYearQualification;
    }

}
