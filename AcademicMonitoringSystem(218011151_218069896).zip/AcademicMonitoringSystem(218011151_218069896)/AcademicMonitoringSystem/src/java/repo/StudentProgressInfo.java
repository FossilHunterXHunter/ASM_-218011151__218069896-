/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repo;

/**
 *
 * @author Student
 */
public class StudentProgressInfo {

    private int ID;
    private String StudentID;
    private int StudentModuleID;
    private int AssessmentTypeID;
    private String AssessmentDescription;
    private int Mark;
    private String Date;
    private User Student;
    private AssessmentType AssessmentType;
    private StudentModules StudentModules;
    private Module Module;

    public StudentProgressInfo() {

    }

    public StudentProgressInfo(int i, String s, int sm, int a, String ad, int m, String d, User stu, AssessmentType at, StudentModules stum, Module mod) {
        ID = i;
        StudentID = s;
        StudentModuleID = sm;
        AssessmentTypeID = a;
        AssessmentDescription = ad;
        Mark = m;
        Date = d;
        Student = stu;
        AssessmentType = at;
        StudentModules = stum;
        Module = mod;
    }

    public StudentProgressInfo(int i, String s, int sm, int a, String ad, int m, String d) {
        ID = i;
        StudentID = s;
        StudentModuleID = sm;
        AssessmentTypeID = a;
        AssessmentDescription = ad;
        Mark = m;
        Date = d;
    }

    public StudentProgressInfo(String s, int sm, int a, String ad, int m, String d) {
        StudentID = s;
        StudentModuleID = sm;
        AssessmentTypeID = a;
        AssessmentDescription = ad;
        Mark = m;
        Date = d;
    }

    public int getID() {
        return ID;
    }

    public void setID(int i) {
        ID = i;
    }

    public String getStudentID() {
        return StudentID;
    }

    public void setStudentID(String s) {
        StudentID = s;
    }

    public int getStudentModuleID() {
        return StudentModuleID;
    }

    public void setStudentModuleID(int sm) {
        StudentModuleID = sm;
    }

    public int getAssessmentTypeID() {
        return AssessmentTypeID;
    }

    public void setAssessmentTypeID(int a) {
        AssessmentTypeID = a;
    }

    public String getAssessmentDescription() {
        return AssessmentDescription;
    }

    public void setAssessmentDescription(String ad) {
        AssessmentDescription = ad;
    }

    public int getMark() {
        return Mark;
    }

    public void setMark(int m) {
        Mark = m;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String d) {
        Date = d;
    }

    public void setStudent(User u) {
        Student = u;
    }

    public User getStudent() {
        return Student;
    }

    public void setAssessmentType(AssessmentType a) {
        AssessmentType = a;
    }

    public AssessmentType getAssessmentType() {
        return AssessmentType;
    }

    public void setStudentModules(StudentModules sm) {
        StudentModules = sm;
    }

    public StudentModules getStudentModules() {
        return StudentModules;
    }

    public void setModule(Module m) {
        Module = m;
    }

    public Module getModule() {
        return Module;
    }
}
