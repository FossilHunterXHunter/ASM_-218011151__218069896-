/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repo;

/**
 *
 * @author Student
 */
public class Programme {

    private int ID;
    private String ProgrammeName;
    private int TotalCredits;
    private int NumberOfYears;
    private int CollegeID;

    public Programme() {
    }

    public Programme(int i, String p, int t, int n, int c) {
        ID = i;
        ProgrammeName = p;
        TotalCredits = t;
        NumberOfYears = n;
        CollegeID = c;
    }

    public Programme(String p, int t, int n, int c) {
        ProgrammeName = p;
        TotalCredits = t;
        NumberOfYears = n;
        CollegeID = c;
    }

    public int getID() {
        return ID;
    }

    public void setID(int i) {
        ID = i;
    }

    public String getProgrammeName() {
        return ProgrammeName;
    }

    public void setProgrammeName(String p) {
        ProgrammeName = p;
    }

    public int getTotalCredits() {
        return TotalCredits;
    }

    public void setTotalCredits(int t) {
        TotalCredits = t;
    }

    public int getNumberOfYears() {
        return NumberOfYears;
    }

    public void setNumberOfYears(int n) {
        NumberOfYears = n;
    }

    public int getCollegeID() {
        return CollegeID;
    }

    public void setCollegeID(int c) {
        CollegeID = c;
    }
}
