/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repo;

/**
 *
 * @author Student
 */
public class StudentModules {

    private int ID;
    private String StudentID;
    private int ModuleID;
    private int Year;
    private int Semester;
    private int Passed;
    
    private Module Module;

    public StudentModules() {

    }

    public StudentModules(int i, String sid, int m, int y, int s, int p) {
        ID = i;
        StudentID = sid;
        ModuleID = m;
        Year = y;
        Semester = s;
        Passed = p;
    }

        public StudentModules(int i, String sid, int m, int y, int s, int p, Module mod) {
        ID = i;
        StudentID = sid;
        ModuleID = m;
        Year = y;
        Semester = s;
        Passed = p;
        Module = mod;
    }
    
    public StudentModules(int i, String sid, int m, int y, int s) {
        ID = i;
        StudentID = sid;
        ModuleID = m;
        Year = y;
        Semester = s;
    }

    public StudentModules(String sid, int m, int y, int s) {
        StudentID = sid;
        ModuleID = m;
        Year = y;
        Semester = s;
    }

    public int getID() {
        return ID;
    }

    public void setID(int i) {
        ID = i;
    }

    public String getStudentID() {
        return StudentID;
    }

    public void setStudentID(String s) {
        StudentID = s;
    }

    public int getModuleID() {
        return ModuleID;
    }

    public void setModuleID(int m) {
        ModuleID = m;
    }

    public int getYear() {
        return Year;
    }

    public void setYear(int y) {
        Year = y;
    }

    public int getSemester() {
        return Semester;
    }

    public void setSemester(int s) {
        Semester = s;
    }

    public int getPassed() {
        return Passed;
    }

    public void setPassed(int p) {
        Passed = p;
    }
    
    public void setModule(Module m){
        Module = m;
    }
    
    public Module getModule(){
        return Module;
    }
}
