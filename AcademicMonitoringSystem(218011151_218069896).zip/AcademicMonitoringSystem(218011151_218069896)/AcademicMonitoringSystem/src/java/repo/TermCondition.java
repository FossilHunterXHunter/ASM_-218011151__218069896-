/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repo;

/**
 *
 * @author Student
 */
public class TermCondition {

    private int ID;
    private String StatusDescription;
    private String Colour;
    private int CreditPercentage;

    public TermCondition() {

    }

    public TermCondition(int i, String s, String c, int cp) {
        ID = i;
        StatusDescription = s;
        Colour = c;
        CreditPercentage = cp;
    }

    public TermCondition(String s, String c, int cp) {
        StatusDescription = s;
        Colour = c;
        CreditPercentage = cp;
    }

    public int getID() {
        return ID;
    }

    public void setID(int i) {
        ID = i;
    }

    public String getStatusDescription() {
        return StatusDescription;
    }

    public void setStatusDescription(String s) {
        StatusDescription = s;
    }

    public String getColour() {
        return Colour;
    }

    public void setColour(String c) {
        Colour = c;
    }

    public int getCreditPercentage() {
        return CreditPercentage;
    }

    public void setCreditPercentage(int c) {
        CreditPercentage = c;
    }
}
