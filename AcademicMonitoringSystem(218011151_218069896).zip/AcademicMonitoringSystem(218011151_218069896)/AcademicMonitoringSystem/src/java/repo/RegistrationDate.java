/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repo;

/**
 *
 * @author Student
 */
public class RegistrationDate {

    private int id;
    private String FromDate;
    private String ToDate;

    public RegistrationDate() {

    }

    public RegistrationDate(String fd, String td) {
        id = 1;
        FromDate = fd;
        ToDate = td;
    }

    public int getID() {
        return id;
    }

    public String getFromDate() {
        return FromDate;
    }

    public void setFromDate(String fd) {
        FromDate = fd;
    }

    public String getToDate() {
        return ToDate;
    }

    public void setToDate(String td) {
        ToDate = td;
    }

}
