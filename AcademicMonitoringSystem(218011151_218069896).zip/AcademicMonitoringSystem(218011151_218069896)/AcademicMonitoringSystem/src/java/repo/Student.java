/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repo;

/**
 *
 * @author Student
 */
public class Student {

    private String StudentID;
    private int ProgrammeID;
    private int TermConditionID;
    private int LastSemesterCalc;
    private int TotalCredits;
    private int TotalSemesters;

    public Student() {

    }

    public Student(String s, int p, int t, int c, int tc, int ts) {
        StudentID = s;
        ProgrammeID = p;
        TermConditionID = t;
        LastSemesterCalc = c;
        TotalCredits = tc;
        TotalSemesters = ts;
    }

    public Student(String s, int p, int t, int c) {
        StudentID = s;
        ProgrammeID = p;
        TermConditionID = t;
        LastSemesterCalc = c;
    }

    public Student(String s, int p, int t) {
        StudentID = s;
        ProgrammeID = p;
        TermConditionID = t;
    }

    public String getStudentID() {
        return StudentID;
    }

    public void setStudentID(String s) {
        StudentID = s;
    }

    public int getProgrammeID() {
        return ProgrammeID;
    }

    public void setProgrammeID(int p) {
        ProgrammeID = p;
    }

    public int getTermConditionID() {
        return TermConditionID;
    }

    public void setTermConditionID(int t) {
        TermConditionID = t;
    }

    public int getLastSemesterCalc() {
        return LastSemesterCalc;
    }

    public void setLastSemesterCalc(int c) {
        LastSemesterCalc = c;
    }

    public int getTotalCredits() {
        return TotalCredits;
    }

    public void setTotalCredits(int c) {
        TotalCredits = c;
    }

    public int getTotalSemesters() {
        return TotalSemesters;
    }

    public void setTotalSemesters(int ts) {
        TotalSemesters = ts;
    }
}
