The following steps outline how to get the programming running. The required software for the program are, Netbeans 8, Jdk 8 and MySQL.

1. Download project folder
2. Open netbeans
3. Open project AcademicMonitoringSystem in netbeans
4. There might be an error(s), right click on AcademicMonitoringSystem and scroll down to resolve errors.
5. For the missing server error, choose add server
6. Select glassfish server
7. Download server
8. For the connector error, go to Local Disk , Program files(x86), MySQL folder
9. Select Connector J folder
10. Select mysql-connector-java-8.0.22.jar
11. Open MySQL workbench and create a new connection called asm
12. The username must be root
13. Set password to server access to krbs
14. In MySQL under management select data import/Restore option
15. Select import from dump project folder
16. Select the folder Dump20201215
17. In the lower right-hand corner of the screen, select start import
18. Once import is completed go to netbeans
19. In netbeans select chrome as the browser
20. Run the program